"use server";

const GEMINI_MODEL = "gemini-3.6-flash";

const SYSTEM_INSTRUCTIONS = `You are Bouldy Coach, a bouldering coach inside a training app. Answer in 2–4 short sentences unless asked for more. Use simple language and explain jargon like Font grades. Use the user's grade and goals only if they are provided and never invent details about the user. If you cannot help or are unsure, say so and suggest what you can help with: technique, training weeks, warm-ups and recovery. Do not give medical advice. If the user mentions pain or an injury, advise resting and speaking to a physiotherapist or doctor. If the user has injuries, avoid exercises that load the injured area, suggest gentler alternatives, never encourage training through pain, recommend seeing a physiotherapist or doctor, and never diagnose. If the user mentions pain or an injury, make today's session gentler or turn it into a rest or mobility session, never train through pain, avoid the injured area, and always advise seeing a physiotherapist or doctor. Never give a diagnosis. For severe pain, swelling, numbness or a suspected fracture, suggest no training today and getting medical help. Only include sessionUpdate when the user's message clearly means today's session should change, such as an injury, pain, tiredness, less available time, or no access to planned equipment. You cannot analyse photos or videos in this chat-prototype, so say so. If a question is unrelated to climbing and training, say it is outside what you can help with here. Use the profile information provided to personalise your answers and do not ask the user for information they have already given.`;

type SessionUpdate = {
  reason: string;
  title: string;
  duration: string;
  steps: Array<{
    title: string;
    instructions: string;
    workLabel: string;
    workSeconds: number;
    restSeconds: number;
  }>;
};

type CoachRequest = {
  message: string;
  conversation?: Array<{
    role: "user" | "coach";
    text: string;
  }>;
  grade?: string;
  goals?: string[];
  experienceLevel?: string;
  fingerTrainingExperience?: string;
  climbingStyle?: string;
  climbingLocation?: string;
  sessionsPerWeek?: string;
  trainingDays?: string[];
  sessionLength?: string;
  equipment?: string[];
  currentInjuries?: string;
  currentSession?: {
    title: string;
    duration: string;
    reason?: string;
    stepTitles?: string[];
  };
};

type CoachResult =
  | { ok: true; reply: string; finishReason: string | null; sessionUpdate?: SessionUpdate }
  | {
      ok: false;
      stage:
        | "secret missing"
        | "request to Gemini failed"
        | "Gemini returned an error"
        | "response could not be read";
      status: number | null;
      message: string;
    };

function sanitizeErrorMessage(message: unknown, apiKey?: string) {
  const rawMessage = typeof message === "string" && message.trim()
    ? message.trim()
    : "Unknown error.";
  const withoutApiKey = apiKey ? rawMessage.replaceAll(apiKey, "[redacted]") : rawMessage;

  return withoutApiKey
    .replace(/([?&](?:key|api_key)=)[^&\s]+/gi, "$1[redacted]")
    .replace(/(x-goog-api-key\s*[:=]\s*)[^\s,;]+/gi, "$1[redacted]")
    .slice(0, 500);
}

function validateSessionUpdate(value: unknown): SessionUpdate | undefined {
  if (!value || typeof value !== "object") return undefined;
  const update = value as Record<string, unknown>;
  const reason = typeof update.reason === "string" ? update.reason.trim() : "";
  const title = typeof update.title === "string" ? update.title.trim() : "";
  const duration = typeof update.duration === "string" ? update.duration.trim() : "";
  if (!reason || reason.length > 240 || !title || title.length > 100 || !duration || duration.length > 30) {
    return undefined;
  }
  if (!Array.isArray(update.steps) || update.steps.length < 1 || update.steps.length > 8) {
    return undefined;
  }

  const steps = update.steps.map((value) => {
    if (!value || typeof value !== "object") return null;
    const step = value as Record<string, unknown>;
    const stepTitle = typeof step.title === "string" ? step.title.trim() : "";
    const instructions = typeof step.instructions === "string" ? step.instructions.trim() : "";
    const workLabel = typeof step.workLabel === "string" ? step.workLabel.trim() : "";
    const workSeconds = typeof step.workSeconds === "number" ? step.workSeconds : NaN;
    const restSeconds = typeof step.restSeconds === "number" ? step.restSeconds : NaN;
    if (
      !stepTitle || stepTitle.length > 100
      || !instructions || instructions.length > 600
      || !workLabel || workLabel.length > 60
      || !Number.isInteger(workSeconds) || workSeconds < 30 || workSeconds > 7_200
      || !Number.isInteger(restSeconds) || restSeconds < 0 || restSeconds > 1_800
    ) {
      return null;
    }
    return { title: stepTitle, instructions, workLabel, workSeconds, restSeconds };
  });

  if (steps.some((step) => step === null)) return undefined;
  const validSteps = steps.filter((step): step is SessionUpdate["steps"][number] => step !== null);
  const totalSeconds = validSteps.reduce((total, step) => total + step.workSeconds + step.restSeconds, 0);
  if (totalSeconds < 300 || totalSeconds > 14_400) return undefined;
  return { reason, title, duration, steps: validSteps };
}

function validateRequest(input: CoachRequest) {
  const message = typeof input.message === "string" ? input.message.trim() : "";
  const cleanText = (value: unknown) =>
    typeof value === "string" ? value.trim().slice(0, 100) : "";
  const cleanInjuries = (value: unknown) =>
    typeof value === "string" ? value.trim().slice(0, 300) : "";
  const cleanList = (value: unknown) =>
    Array.isArray(value)
      ? value
          .filter((item): item is string => typeof item === "string")
          .map((item) => item.trim())
          .filter(Boolean)
          .join(", ")
          .slice(0, 100)
      : "";
  const conversation = Array.isArray(input.conversation)
    ? input.conversation
        .slice(-6)
        .filter(
          (item): item is { role: "user" | "coach"; text: string } =>
            typeof item === "object" &&
            item !== null &&
            (item.role === "user" || item.role === "coach") &&
            typeof item.text === "string",
        )
        .map(({ role, text }) => ({ role, text: text.trim().slice(0, 2_000) }))
        .filter(({ text }) => Boolean(text))
    : [];
  const currentSession = input.currentSession && typeof input.currentSession === "object"
    ? {
        title: cleanText(input.currentSession.title),
        duration: cleanText(input.currentSession.duration).slice(0, 30),
        reason: typeof input.currentSession.reason === "string"
          ? input.currentSession.reason.trim().slice(0, 240)
          : "",
        stepTitles: cleanList(input.currentSession.stepTitles),
      }
    : null;
  const profile = {
    grade: cleanText(input.grade),
    goals: cleanList(input.goals),
    experienceLevel: cleanText(input.experienceLevel),
    fingerTrainingExperience: cleanText(input.fingerTrainingExperience),
    climbingStyle: cleanText(input.climbingStyle),
    climbingLocation: cleanText(input.climbingLocation),
    sessionsPerWeek: cleanText(input.sessionsPerWeek),
    trainingDays: cleanList(input.trainingDays),
    sessionLength: cleanText(input.sessionLength),
    equipment: cleanList(input.equipment),
    currentInjuries: cleanInjuries(input.currentInjuries),
  };

  if (!message || message.length > 2_000) return null;
  return { message, conversation, currentSession, ...profile };
}

export async function askBouldyCoach(input: CoachRequest): Promise<CoachResult> {
  let apiKey: string | undefined;
  try {
    const request = validateRequest(input);
    apiKey = process.env.APP_GEMINI_API_KEY;

    if (!apiKey) {
      return {
        ok: false,
        stage: "secret missing",
        status: null,
        message: "Gemini API key is not configured.",
      };
    }

    if (!request) {
      return {
        ok: false,
        stage: "request to Gemini failed",
        status: null,
        message: "Invalid Coach request.",
      };
    }

    const profileContext = [
      request.grade ? `User grade: ${request.grade}.` : "",
      request.goals ? `User goals: ${request.goals}.` : "",
      request.experienceLevel ? `User experience level: ${request.experienceLevel}.` : "",
      request.fingerTrainingExperience ? `User finger training experience: ${request.fingerTrainingExperience}.` : "",
      request.climbingStyle ? `User climbing style: ${request.climbingStyle}.` : "",
      request.climbingLocation ? `User climbing location: ${request.climbingLocation}.` : "",
      request.sessionsPerWeek ? `User sessions per week: ${request.sessionsPerWeek}.` : "",
      request.trainingDays ? `User training days: ${request.trainingDays}.` : "",
      request.sessionLength ? `User session length: ${request.sessionLength}.` : "",
      request.equipment ? `User equipment: ${request.equipment}.` : "",
      request.currentInjuries ? `User current injuries: ${request.currentInjuries}.` : "",
    ]
      .filter(Boolean)
      .join("\n");
    const currentSessionContext = request.currentSession?.title
      ? [
          `Current session title: ${request.currentSession.title}.`,
          request.currentSession.duration ? `Current session duration: ${request.currentSession.duration}.` : "",
          request.currentSession.reason ? `Current session reason: ${request.currentSession.reason}.` : "",
          request.currentSession.stepTitles ? `Current session step titles: ${request.currentSession.stepTitles}.` : "",
        ].filter(Boolean).join("\n")
      : "";

    let response: Response;
    try {
      response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-goog-api-key": apiKey,
          },
          body: JSON.stringify({
            system_instruction: {
              parts: [
                {
                  text: profileContext
                    ? `${SYSTEM_INSTRUCTIONS}\n\n${profileContext}${currentSessionContext ? `\n\n${currentSessionContext}` : ""}`
                    : `${SYSTEM_INSTRUCTIONS}${currentSessionContext ? `\n\n${currentSessionContext}` : ""}`,
                },
              ],
            },
            contents: [
              ...request.conversation.map(({ role, text }) => ({
                role: role === "coach" ? "model" : "user",
                parts: [{ text }],
              })),
              {
                role: "user",
                parts: [{ text: request.message }],
              },
            ],
          generationConfig: {
            maxOutputTokens: 1024,
            temperature: 0.5,
            responseMimeType: "application/json",
            responseSchema: {
              type: "OBJECT",
              properties: {
                reply: { type: "STRING" },
                sessionUpdate: {
                  type: "OBJECT",
                  properties: {
                    reason: { type: "STRING" },
                    title: { type: "STRING" },
                    duration: { type: "STRING" },
                    steps: {
                      type: "ARRAY",
                      maxItems: 8,
                      items: {
                        type: "OBJECT",
                        properties: {
                          title: { type: "STRING" },
                          instructions: { type: "STRING" },
                          workLabel: { type: "STRING" },
                          workSeconds: { type: "INTEGER" },
                          restSeconds: { type: "INTEGER" },
                        },
                        required: ["title", "instructions", "workLabel", "workSeconds", "restSeconds"],
                      },
                    },
                  },
                  required: ["reason", "title", "duration", "steps"],
                },
              },
              required: ["reply"],
            },
            thinkingConfig: {
              thinkingLevel: "MINIMAL",
            },
          },
          }),
          cache: "no-store",
        },
      );
    } catch (error) {
      return {
        ok: false,
        stage: "request to Gemini failed",
        status: null,
        message: sanitizeErrorMessage(error instanceof Error ? error.message : error, apiKey),
      };
    }

    if (!response.ok) {
      let data: { error?: { message?: string } } | null;
      try {
        data = (await response.json()) as { error?: { message?: string } };
      } catch (error) {
        return {
          ok: false,
          stage: "response could not be read",
          status: response.status,
          message: sanitizeErrorMessage(error instanceof Error ? error.message : error, apiKey),
        };
      }

      return {
        ok: false,
        stage: "Gemini returned an error",
        status: response.status,
        message: sanitizeErrorMessage(data?.error?.message || response.statusText, apiKey),
      };
    }

    let data: {
      candidates?: Array<{
        finishReason?: string;
        content?: {
          parts?: Array<{ text?: string }>;
        };
      }>;
    };
    try {
      data = (await response.json()) as typeof data;
    } catch (error) {
      return {
        ok: false,
        stage: "response could not be read",
        status: response.status,
        message: sanitizeErrorMessage(error instanceof Error ? error.message : error, apiKey),
      };
    }

    const responseText = data.candidates?.[0]?.content?.parts
      ?.map((part) => part.text)
      .filter((text): text is string => Boolean(text))
      .join("")
      .trim();
    const finishReason = data.candidates?.[0]?.finishReason?.trim() || null;
    let parsed: { reply?: unknown; sessionUpdate?: unknown } | null = null;
    if (responseText) {
      try {
        parsed = JSON.parse(responseText) as { reply?: unknown; sessionUpdate?: unknown };
      } catch {
        parsed = null;
      }
    }
    const reply = typeof parsed?.reply === "string"
      ? parsed.reply.trim().slice(0, 2_000)
      : "";
    const sessionUpdate = validateSessionUpdate(parsed?.sessionUpdate);

    return reply
      ? { ok: true, reply, finishReason, ...(sessionUpdate ? { sessionUpdate } : {}) }
      : {
          ok: false,
          stage: "response could not be read",
          status: response.status,
          message: "Gemini returned no text response.",
        };
  } catch (error) {
    return {
      ok: false,
      stage: "request to Gemini failed",
      status: null,
      message: sanitizeErrorMessage(error instanceof Error ? error.message : error, apiKey),
    };
  }
}
