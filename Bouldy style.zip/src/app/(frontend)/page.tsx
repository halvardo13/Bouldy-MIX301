import BouldyApp from "./bouldy-app";

export default function HomePage() {
  return <BouldyApp />;
}
