"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { askBouldyCoach } from "./coach-actions";

const welcomeIllustration = "/assets/boulder-wall-illustration.svg";
const warmupIllustration = "/assets/climber-illustration-recolored.png";

type AppView = "today" | "coach" | "workout" | "warmup" | "analyze" | "history" | "settings" | "data-policy";
type WarmupArea = "Full body" | "Neck" | "Shoulders" | "Arms" | "Wrists" | "Hips" | "Legs" | "Ankles";
type IconName =
  | "arrow"
  | "bookmark"
  | "calendar"
  | "camera"
  | "check"
  | "chevron"
  | "clock"
  | "close"
  | "history"
  | "home"
  | "image"
  | "message"
  | "microphone"
  | "mountain"
  | "play"
  | "plus"
  | "footprints"
  | "refresh"
  | "send"
  | "spark"
  | "stopwatch"
  | "target"
  | "user"
  | "warmup"
  | "workout";

type WorkoutLog = {
  id: number;
  completedAt: string;
  title: string;
  date: string;
  duration: string;
  grade: string;
  result: string;
};

type StoredWorkoutLog = Omit<WorkoutLog, "completedAt"> & { completedAt?: string };

function normalizeWorkoutLog(log: StoredWorkoutLog): WorkoutLog {
  return {
    ...log,
    completedAt: log.completedAt || new Date(log.id).toISOString(),
  };
}

type WorkoutStep = {
  title: string;
  instructions: string;
  workLabel: string;
  workSeconds: number;
  restSeconds: number;
};

type WorkoutPlan = {
  title: string;
  duration: string;
  steps: WorkoutStep[];
};

type SessionUpdate = WorkoutPlan & { reason: string };

type ChatMessage = {
  role: "coach" | "user";
  text: string;
  attachment?: string;
  debugError?: string;
  sessionUpdate?: SessionUpdate;
  sessionDecision?: "accepted" | "kept";
  injuryToSave?: string;
  injurySaved?: boolean;
};

type SavedChatMessage = ChatMessage & { id: string };

type UserProfile = {
  name: string;
  email?: string;
  grade: string;
  note: string;
  height: string;
  armSpan: string;
  gender?: string;
  weight?: string;
  goals: string[];
  climbingYears?: string;
  climbingStyle?: string;
  climbingLocation?: string;
  experienceLevel?: string;
  fingerTrainingExperience?: string;
  targetGrade?: string;
  currentInjuries?: string;
  pastInjuries?: string;
  sessionsPerWeek?: string;
  trainingDays?: string[];
  sessionLength?: string;
  equipment?: string[];
  trainingStructure?: string;
  biggestChallenge?: string;
  failureResponse?: string;
};

type GeneratedTodaySession = {
  plan: WorkoutPlan;
  reason: string;
  adjustedByCoach?: boolean;
  adaptedForProfileInjury?: boolean;
};

type CachedTodaySession = {
  date: string;
  profileSignature: string;
  session: GeneratedTodaySession;
};

function localDateKey(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function generateTodaySession(profile: UserProfile, logs: WorkoutLog[]): GeneratedTodaySession {
  const now = new Date();
  const isGuest = !profile.name.trim();
  const equipment = profile.equipment || [];
  const experience = (profile.experienceLevel || "Beginner").toLowerCase();
  const fingerExperience = (profile.fingerTrainingExperience || "Beginner").toLowerCase();
  const injuries = profile.currentInjuries?.trim() || "";
  const goal = profile.goals[0]?.trim() || "";
  const goalText = goal.toLowerCase();
  const hasHangboard = equipment.includes("Hangboard");
  const hasClimbingSurface = equipment.some((item) => ["Climbing wall", "Kilter board", "Spray wall"].includes(item))
    || profile.climbingLocation === "Outdoors"
    || profile.climbingLocation === "Both";
  const canUseFingerWork = hasHangboard
    && (fingerExperience === "intermediate" || fingerExperience === "advanced")
    && !injuries;
  const isBeginner = isGuest || experience === "beginner";
  const climbingNoun = profile.climbingStyle?.toLowerCase().includes("boulder") ? "problems" : "routes";
  const locationPhrase = profile.climbingLocation === "Outdoors"
    ? "at your usual outdoor climbing area"
    : profile.climbingLocation === "Both"
      ? "at your indoor wall or usual outdoor climbing area"
      : "at your indoor wall";

  const weekStart = new Date(now);
  weekStart.setHours(0, 0, 0, 0);
  weekStart.setDate(weekStart.getDate() - ((weekStart.getDay() + 6) % 7));
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekEnd.getDate() + 7);
  const thisWeekLogs = logs.filter((log) => {
    const completedAt = new Date(log.completedAt);
    return completedAt >= weekStart && completedAt < weekEnd;
  });
  const weeklyTarget = Number.parseInt(profile.sessionsPerWeek || "", 10) || 0;
  const targetReached = weeklyTarget > 0 && thisWeekLogs.length >= weeklyTarget;
  const yesterdayStart = new Date(now);
  yesterdayStart.setHours(0, 0, 0, 0);
  yesterdayStart.setDate(yesterdayStart.getDate() - 1);
  const todayStart = new Date(yesterdayStart);
  todayStart.setDate(todayStart.getDate() + 1);
  const trainedHardYesterday = logs.some((log) => {
    const completedAt = new Date(log.completedAt);
    return completedAt >= yesterdayStart
      && completedAt < todayStart
      && /strength|power|limit|project|hangboard|finger/i.test(log.title);
  });
  const todayName = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][now.getDay()];
  const offTrainingDay = Boolean(profile.trainingDays?.length && !profile.trainingDays.includes(todayName));
  const lighterSession = Boolean(injuries || trainedHardYesterday || targetReached || offTrainingDay);

  const durationRanges: Record<string, [number, number]> = {
    "30–45 min": [30, 45],
    "45–60 min": [45, 60],
    "60–90 min": [60, 90],
    "90+ min": [90, 90],
  };
  const selectedRange = durationRanges[profile.sessionLength || ""] || (isGuest ? [40, 45] : [45, 60]);
  const totalMinutes = lighterSession
    ? selectedRange[0]
    : Math.round((selectedRange[0] + selectedRange[1]) / 2);
  const duration = profile.sessionLength || `${totalMinutes} min`;

  let focus = "movement";
  if (/technique|static|dynamic|movement|footwork/.test(goalText)) focus = "technique";
  else if (/strength|strong|power|finger/.test(goalText)) focus = "strength";
  else if (/endurance|stamina|fitness/.test(goalText)) focus = "endurance";
  else if (/project|grade|plateau|competition/.test(goalText)) focus = "projecting";

  let reason: string;
  if (isGuest) reason = "a balanced beginner session builds confidence and movement quality.";
  else if (injuries) reason = "you noted an injury, so this session lowers intensity and keeps every movement pain-free.";
  else if (offTrainingDay) reason = "today is outside your preferred training days, so this is an optional mobility and recovery session.";
  else if (trainedHardYesterday) reason = "yesterday was a hard session, so today focuses on lighter technique and recovery.";
  else if (targetReached) reason = "you reached your weekly target, so today stays light and restorative.";
  else if (goal) reason = `your main focus is ${goal.toLowerCase()}.`;
  else reason = "a balanced session supports steady progress.";

  const middleSteps: Array<{ title: string; instructions: string; restSeconds: number }> = [];
  const injuryGuidance = injuries
    ? ` Avoid loading the injured area (${injuries}) and stop if pain increases.`
    : "";

  if (lighterSession) {
    middleSteps.push({
      title: offTrainingDay ? "Optional mobility" : "Easy movement practice",
      instructions: hasClimbingSurface
        ? `Move through very easy ${climbingNoun} ${locationPhrase}. Keep effort low and focus on smooth, relaxed movement.${injuryGuidance}`
        : `Use gentle, equipment-free mobility and controlled movement. Stay well inside a pain-free range.${injuryGuidance}`,
      restSeconds: 30,
    });
    middleSteps.push({
      title: "Recovery technique",
      instructions: `Practice quiet feet, relaxed breathing, and precise movement without chasing difficulty.${injuryGuidance}`,
      restSeconds: 30,
    });
  } else {
    middleSteps.push({
      title: isBeginner
        ? "Easy volume"
        : hasClimbingSurface
          ? `Limit attempts around Font ${profile.grade || "your current grade"}`
          : "Controlled strength",
      instructions: isBeginner
        ? `Complete comfortable ${climbingNoun} ${locationPhrase}, resting before form fades. Choose easier volume and prioritize control.`
        : hasClimbingSurface
          ? `Make a small number of high-quality attempts on ${climbingNoun} around Font ${profile.grade || "your current grade"} ${locationPhrase}. Rest fully and refine one decision each attempt.`
          : "Use the equipment you have for controlled, low-volume strength work. Stop each set before form changes.",
      restSeconds: isBeginner ? 45 : 120,
    });

    const focusInstructions = focus === "technique"
      ? `Practice precise feet, balanced body positions, and efficient movement on comfortable ${climbingNoun}.`
      : focus === "strength"
        ? hasClimbingSurface
          ? `Use powerful but controlled moves on a small number of ${climbingNoun}, with full rest between efforts.`
          : equipment.includes("Weights / gym")
            ? "Use your available weights for controlled pulling and shoulder-stability work."
            : "Use slow bodyweight pulling and core-tension drills with strict form."
        : focus === "endurance"
          ? hasClimbingSurface
            ? `Link easy ${climbingNoun} into steady intervals, keeping enough energy to maintain good technique.`
            : "Use continuous low-intensity mobility and bodyweight movement at a conversational pace."
          : hasClimbingSurface
            ? `Work one project near Font ${profile.grade || "your current grade"}, using deliberate attempts and full rests.`
            : "Rehearse movement sequences and build general strength with the equipment available.";
    middleSteps.push({
      title: focus === "technique" ? "Technique focus" : focus === "strength" ? "Strength focus" : focus === "endurance" ? "Endurance focus" : "Project focus",
      instructions: focusInstructions,
      restSeconds: focus === "endurance" ? 60 : 90,
    });
  }

  if (canUseFingerWork && focus === "strength" && !lighterSession) {
    middleSteps.push({
      title: "Controlled hangboard work",
      instructions: "Use large comfortable holds, keep your shoulders active, and stop well before failure. Never train through finger pain.",
      restSeconds: 120,
    });
  }

  const warmupMinutes = Math.max(6, Math.round(totalMinutes * 0.18));
  const cooldownMinutes = Math.max(5, Math.round(totalMinutes * 0.1));
  const middleMinutes = totalMinutes - warmupMinutes - cooldownMinutes;
  const baseMiddleMinutes = Math.floor(middleMinutes / middleSteps.length);
  const steps: WorkoutStep[] = [
    {
      title: "Progressive warm-up",
      instructions: `Raise your pulse, mobilize shoulders, hips, wrists, and ankles, then rehearse easy climbing movements.${injuryGuidance}`,
      workLabel: `${warmupMinutes} min`,
      workSeconds: warmupMinutes * 60,
      restSeconds: 0,
    },
    ...middleSteps.map((step, index) => {
      const allocatedMinutes = index === middleSteps.length - 1
        ? middleMinutes - baseMiddleMinutes * (middleSteps.length - 1)
        : baseMiddleMinutes;
      return {
        ...step,
        workLabel: `${allocatedMinutes} min`,
        workSeconds: Math.max(60, allocatedMinutes * 60 - step.restSeconds),
      };
    }),
    {
      title: "Cool-down",
      instructions: injuries
        ? "Finish with easy breathing and gentle pain-free mobility. Consider seeing a physiotherapist or doctor about the injured area."
        : "Finish with easy breathing, gentle mobility, and a short note about what felt smooth or difficult.",
      workLabel: `${cooldownMinutes} min`,
      workSeconds: cooldownMinutes * 60,
      restSeconds: 0,
    },
  ];

  const title = lighterSession
    ? offTrainingDay ? "Optional mobility & recovery" : "Technique & recovery"
    : focus === "technique" ? "Precision & movement"
      : focus === "strength" ? "Strength & power"
        : focus === "endurance" ? "Climbing endurance"
          : "Project session";

  return {
    plan: { title, duration, steps },
    reason,
    adaptedForProfileInjury: Boolean(injuries),
  };
}

function saveTodaySession(profile: UserProfile, session: GeneratedTodaySession) {
  const cached: CachedTodaySession = {
    date: localDateKey(),
    profileSignature: JSON.stringify(profile),
    session,
  };
  localStorage.setItem("bouldy-today-session", JSON.stringify(cached));
}

function getTodaySession(profile: UserProfile, logs: WorkoutLog[]): GeneratedTodaySession {
  const date = localDateKey();
  const profileSignature = JSON.stringify(profile);
  try {
    const cached = JSON.parse(localStorage.getItem("bouldy-today-session") || "null") as CachedTodaySession | null;
    if (
      cached?.date === date
      && cached.profileSignature === profileSignature
      && cached.session?.plan?.steps?.length
    ) {
      return cached.session;
    }
  } catch {
    // Regenerate below when the local cache is missing or malformed.
  }

  const session = generateTodaySession(profile, logs);
  saveTodaySession(profile, session);
  return session;
}

function resetTodaySession(profile: UserProfile, logs: WorkoutLog[]) {
  const session = generateTodaySession(profile, logs);
  saveTodaySession(profile, session);
  return session;
}

const FONT_GRADES = [
  "3",
  "4",
  "5",
  "5+",
  "6A",
  "6A+",
  "6B",
  "6B+",
  "6C",
  "6C+",
  "7A",
  "7A+",
  "7B",
  "7B+",
  "7C",
  "7C+",
  "8A",
  "8A+",
  "8B",
  "8B+",
  "8C",
];

const WARMUPS: Record<WarmupArea, { title: string; time: string; note: string }[]> = {
  "Full body": [
    { title: "Pulse raiser", time: "3 min", note: "Easy jumping jacks, jogging in place, or a brisk walk." },
    { title: "World's greatest stretch", time: "2 min", note: "Move slowly through a lunge, rotation, and hamstring fold." },
    { title: "Easy climbing", time: "5 min", note: "Traverse or climb three very easy problems with quiet feet." },
  ],
  Neck: [
    { title: "Chin tucks", time: "10 reps", note: "Gently draw your chin straight back. Keep your gaze level." },
    { title: "Side tilts", time: "30 sec each", note: "Ear toward shoulder. No pulling — let gravity do the work." },
    { title: "Slow neck rotations", time: "60 sec", note: "Turn chin toward each shoulder through a comfortable range. Never force." },
  ],
  Shoulders: [
    { title: "Arm circles", time: "60 sec", note: "Build from small circles to full, controlled shoulder rotations." },
    { title: "Scapular pull-ups", time: "2 × 6", note: "Keep arms straight and move only through the shoulder blades." },
    { title: "Band pull-aparts", time: "2 × 10", note: "Use a light band and keep your ribs down." },
  ],
  Arms: [
    { title: "Tendon glides", time: "60 sec", note: "Move from open hand to hook, straight fist, then full fist." },
    { title: "Finger flicks", time: "45 sec", note: "Flick each finger open with control. Keep your forearms relaxed." },
    { title: "Easy open-hand hangs", time: "3 × 7 sec", note: "Feet supported. Use a large edge and stop well before fatigue." },
  ],
  Wrists: [
    { title: "Wrist circles", time: "45 sec", note: "Interlace your fingers and move through a comfortable range." },
    { title: "Palm pulses", time: "60 sec", note: "On all fours, gently shift weight forward over your hands." },
    { title: "Reverse palm stretch", time: "30 sec", note: "Turn fingers toward your knees and lean back very gently." },
  ],
  Hips: [
    { title: "90/90 switches", time: "60 sec", note: "Rotate side to side without forcing the end position." },
    { title: "Deep squat shifts", time: "60 sec", note: "Stay tall and shift gently between left and right." },
    { title: "High-step practice", time: "2 × 6", note: "Place a high foot and bring your hips over it with control." },
  ],
  Legs: [
    { title: "Quad stretch", time: "30 sec each", note: "Stand tall, pull your heel to your glute. Don't arch your back." },
    { title: "Calf raises", time: "2 × 12", note: "Rise slowly through the big toe and pause at the top." },
    { title: "Reverse lunges", time: "2 × 6", note: "Keep the front foot planted and move through a full range." },
  ],
  Ankles: [
    { title: "Ankle circles", time: "45 sec each", note: "Slow, controlled rotations. Trace a wide circle with your toes." },
    { title: "Ankle rocks", time: "60 sec", note: "Drive each knee over the toes while keeping your heel flat." },
    { title: "Single-leg balance", time: "30 sec each", note: "Stand on one foot and find a stable position before adding movement." },
  ],
};

const INTRO_SLIDES = [
  {
    id: "welcome",
    eyebrow: "Welcome to Bouldy",
    title: "Your personal AI\nbouldering coach",
    body: "Designed for boulderers who want to train smarter — not just harder.",
  },
  {
    id: "today",
    eyebrow: "Daily plan",
    title: "A personalized session,\nevery day",
    body: "Bouldy reads your history, grade, and goals to build today's training plan just for you.",
  },
  {
    id: "coach",
    eyebrow: "AI Coach",
    title: "Ask anything, get\nexpert guidance",
    body: "Stuck on a problem? Upload a photo or describe the move. Your coach responds instantly.",
  },
  {
    id: "workouts",
    eyebrow: "Workouts",
    title: "Structured training\nthat compounds",
    body: "Follow coach-built programs, track every send, and watch your progress build week by week.",
  },
  {
    id: "warmup",
    eyebrow: "Warm Up",
    title: "Protect your body,\nclimb longer",
    body: "Targeted routines for the whole body, fingers, wrists, shoulders, and hips — built for climbers, by climbers.",
  },
];

const COACH_PROMPT_SETS = [
  ["Build my next workout", "Help with a project", "Review my technique"],
  ["Plan my training week", "Improve my footwork", "How should I recover?"],
  ["Break through a plateau", "Prepare for a competition", "Train finger strength safely"],
];

const GOALS = [
  "Get stronger",
  "Better static movement",
  "Better dynamic movement",
  "Improve technique",
  "Feel good climbing",
  "Train hard",
  "Get ready for a competition",
  "Prepare for a trip",
  "Send a project",
];

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const common = { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.8, strokeLinecap: "round" as const, strokeLinejoin: "round" as const, "aria-hidden": true };
  const paths: Record<IconName, React.ReactNode> = {
    arrow: <><path d="M5 12h14" /><path d="m14 7 5 5-5 5" /></>,
    bookmark: <path d="M6 4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18l-6-4-6 4V4Z" />,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 10h18" /></>,
    camera: <><path d="M14.5 5 13 3h-2L9.5 5H6a3 3 0 0 0-3 3v9a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V8a3 3 0 0 0-3-3h-3.5Z" /><circle cx="12" cy="12.5" r="3.5" /></>,
    check: <path d="m5 12 4 4L19 6" />,
    chevron: <path d="m9 18 6-6-6-6" />,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    close: <><path d="m6 6 12 12M18 6 6 18" /></>,
    history: <><path d="M3 12a9 9 0 1 0 3-6.7L3 8" /><path d="M3 3v5h5M12 7v5l3 2" /></>,
    home: <><path d="m3 11 9-8 9 8" /><path d="M5 10v10h14V10M9 20v-6h6v6" /></>,
    image: <><rect x="3" y="4" width="18" height="16" rx="2" /><circle cx="8.5" cy="9" r="1.5" /><path d="m21 15-5-5L5 20" /></>,
    message: <><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z" /><path d="M8 9h8M8 13h5" /></>,
    microphone: <><rect x="9" y="3" width="6" height="11" rx="3" /><path d="M5 11a7 7 0 0 0 14 0M12 18v3M9 21h6" /></>,
    mountain: <><path d="M3 20 10 7l4 7 2-3 5 9H3Z" /><path d="m8 11 2 2 2-2" /></>,
    play: <path d="m8 5 11 7-11 7Z" />,
    plus: <><path d="M12 5v14M5 12h14" /></>,
    footprints: <><path d="M8.5 13.5c2.3.8 4.7-.7 5.4-3.4.8-2.7-.4-5.5-2.7-6.2-2.3-.8-4.7.7-5.5 3.4-.7 2.7.5 5.5 2.8 6.2Z" /><path d="M15.4 20.6c1.8.6 3.8-.6 4.4-2.8.6-2.1-.4-4.3-2.2-4.9-1.8-.6-3.8.7-4.4 2.8-.6 2.2.4 4.4 2.2 4.9Z" /></>,
    refresh: <><path d="M20 7v5h-5" /><path d="M4 17v-5h5" /><path d="M6.1 8a7 7 0 0 1 11.7-2.6L20 8M4 16l2.2 2.6A7 7 0 0 0 17.9 16" /></>,
    send: <><path d="m22 2-7 20-4-9-9-4Z" /><path d="M22 2 11 13" /></>,
    spark: <><path d="m12 3 1.4 4.1L18 9l-4.6 1.9L12 15l-1.4-4.1L6 9l4.6-1.9Z" /><path d="m19 15 .7 2.3L22 18l-2.3.7L19 21l-.7-2.3L16 18l2.3-.7Z" /></>,
    stopwatch: <><circle cx="12" cy="13" r="8" /><path d="M12 9v4l2 2M9 2h6M17.5 5.5 19 4" /></>,
    target: <><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="5" /><circle cx="12" cy="12" r="1" /></>,
    user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
    warmup: <><path d="M7 20c-3-2-3-6 0-8 3-2 3-6 0-8M17 4c3 2 3 6 0 8-3 2-3 6 0 8" /><path d="M10 7h4M10 17h4" /></>,
    workout: <><path d="M6 7v10M3 10v4M18 7v10M21 10v4M6 12h12" /></>,
  };
  return <svg {...common}>{paths[name]}</svg>;
}

function Heading({ children, level = 2, className = "" }: { children: React.ReactNode; level?: number; className?: string }) {
  return <div role="heading" aria-level={level} className={`heading ${className}`}>{children}</div>;
}

function Button({ children, className = "", variant = "primary", ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "secondary" | "ghost" | "icon" }) {
  return <button className={`button button-${variant} ${className}`} {...props}>{children}</button>;
}

function SlideVisual({ id }: { id: string }) {
  switch (id) {
    case "welcome":
      return (
        <img className="welcome-illustration" src={warmupIllustration} alt="" aria-hidden />
      );

    case "today":
      return (
        <svg viewBox="0 0 320 220" fill="none" aria-hidden>
          {(["M","T","W","T","F","S","S"] as const).map((d, i) => (
            <g key={i} transform={`translate(${56 + i * 32}, 46)`}>
              <text x="11" y="14" textAnchor="middle" fill="#a9bba3" fontSize="9" fontFamily="Space Grotesk, sans-serif" opacity={0.6}>{d}</text>
              <rect x="0" y="20" width="22" height="28" rx="7"
                fill={i < 3 ? "#4e7d5b" : i === 3 ? "#dafa72" : "#223228"}
                opacity={i > 3 ? 0.5 : 1}
              />
              {i < 3 && <path d="M6 34l4 4 8-8" stroke="white" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" />}
              {i === 3 && <circle cx="11" cy="34" r="3" fill="white" />}
            </g>
          ))}
          <rect x="52" y="110" width="216" height="82" rx="14" fill="#223228" />
          <rect x="70" y="126" width="90" height="8" rx="4" fill="#4e7d5b" opacity={0.65} />
          <rect x="70" y="142" width="152" height="6" rx="3" fill="#344137" />
          <rect x="70" y="156" width="124" height="6" rx="3" fill="#344137" />
          <rect x="70" y="170" width="90" height="6" rx="3" fill="#344137" />
          <circle cx="234" cy="152" r="16" fill="#dafa72" opacity={0.12} />
          <path d="M228 152l4 4 9-9" stroke="#dafa72" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );

    case "coach":
      return (
        <svg viewBox="0 0 320 220" fill="none" aria-hidden>
          <rect x="36" y="30" width="190" height="68" rx="18" fill="#223228" />
          <path d="M52 98l-14 16h18" fill="#223228" />
          <rect x="54" y="48" width="120" height="8" rx="4" fill="#4e7d5b" opacity={0.7} />
          <rect x="54" y="64" width="154" height="7" rx="3.5" fill="#344137" />
          <rect x="54" y="79" width="96" height="7" rx="3.5" fill="#344137" />
          <path d="M240 42l2.2 6.5 6.8 2.2-6.8 2.2L240 59l-2.2-6.1-6.8-2.2 6.8-2.2z" fill="#dafa72" opacity={0.85} />
          <rect x="94" y="130" width="190" height="58" rx="18" fill="#315c3d" />
          <path d="M268 174l14 16h-18" fill="#315c3d" />
          <rect x="112" y="147" width="130" height="8" rx="4" fill="white" opacity={0.5} />
          <rect x="112" y="163" width="88" height="8" rx="4" fill="white" opacity={0.3} />
          <circle cx="82" cy="140" r="12" fill="#315c3d" />
          <path d="M78 140l3 3 6-6" stroke="white" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );

    case "workouts":
      return (
        <svg viewBox="0 0 320 220" fill="none" aria-hidden>
          <rect x="42" y="24" width="236" height="172" rx="28" fill="#202B23" />
          <path d="M42 73c42-18 71-8 104-25 39-20 82-20 132 2" stroke="#345441" strokeWidth="1.5" opacity=".65" />
          <path d="M42 166c35-17 65-11 96 2 41 18 82 15 140-8" stroke="#345441" strokeWidth="1.5" opacity=".55" />

          <rect x="104" y="42" width="112" height="25" rx="8" fill="#345441" />
          <rect x="115" y="49" width="25" height="7" rx="3.5" fill="#E0F57A" />
          <rect x="147" y="49" width="22" height="7" rx="3.5" fill="#E0F57A" />
          <rect x="176" y="49" width="29" height="7" rx="3.5" fill="#E0F57A" />
          <path d="M128 58v11M192 58v11" stroke="#D5DDD3" strokeWidth="2.5" strokeLinecap="round" />

          <path d="M128 63c4 0 7 3 7 7l1 22c1 12 5 21 14 29l-8 10c-13-10-19-23-20-38l-1-23c0-4 3-7 7-7Z" fill="#D5DDD3" />
          <path d="M192 63c-4 0-7 3-7 7l-1 22c-1 12-5 21-14 29l8 10c13-10 19-23 20-38l1-23c0-4-3-7-7-7Z" fill="#D5DDD3" />
          <path d="M123 61c1-4 4-6 8-6 5 1 7 4 7 9l-2 8-14-2 1-9ZM197 61c-1-4-4-6-8-6-5 1-7 4-7 9l2 8 14-2-1-9Z" fill="#D5DDD3" />
          <path d="M125 59v9M129 58v10M133 59v9M195 59v9M191 58v10M187 59v9" stroke="#202B23" strokeWidth="1.2" strokeLinecap="round" opacity=".65" />
          <rect x="120" y="79" width="17" height="7" rx="3.5" fill="#345441" />
          <rect x="121.5" y="80.5" width="6" height="4" rx="1.5" fill="#E0F57A" />

          <path d="M147 117c4-5 8-7 13-7s9 2 13 7c5 7 7 18 8 31l-6 35h-30l-6-35c1-13 3-24 8-31Z" fill="#D5DDD3" />
          <path d="M145 124c3-5 7-8 11-9l4 12 4-12c4 1 8 4 11 9l-3 55c-8 3-16 3-24 0l-3-55Z" fill="#345441" />
          <path d="m151 118 9 13 9-13M160 131v17" stroke="#202B23" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          <path d="m151 117 9 14 9-14" stroke="#E0F57A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M143 126c4 2 8 1 12-2M177 126c-4 2-8 1-12-2" stroke="#345441" strokeWidth="1.8" strokeLinecap="round" opacity=".75" />
          <path d="M146 164c9 4 19 4 28 0" stroke="#345441" strokeWidth="2" strokeLinecap="round" opacity=".85" />

          <rect x="154" y="105" width="12" height="13" rx="5" fill="#D5DDD3" />
          <circle cx="160" cy="102" r="13" fill="#D5DDD3" />
          <path d="M148 103c-1-10 4-17 12-17 7 0 13 6 13 14 0 7-4 12-9 15-4-5-9-8-16-12Z" fill="#B8674B" />
          <path d="M154 92c6-5 15-2 18 4M169 105c5 2 8 7 6 12-2 4-6 6-11 5 3-4 3-8 0-11" fill="#B8674B" />
          <path d="M151 105c2 4 6 7 10 8" stroke="#345441" strokeWidth="1.5" strokeLinecap="round" opacity=".7" />

          <path d="M145 177c10 3 20 3 30 0l4 19h-38l4-19Z" fill="#41654F" />
          <path d="M160 181v15" stroke="#202B23" strokeWidth="1.5" opacity=".55" />

          <rect x="58" y="82" width="39" height="50" rx="12" fill="#345441" />
          <circle cx="77.5" cy="101.5" r="10.5" stroke="#E0F57A" strokeWidth="2" />
          <path d="M77.5 95v7l4 3" stroke="#E0F57A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <rect x="68" y="119" width="19" height="4" rx="2" fill="#41654F" />

          <rect x="223" y="91" width="39" height="40" rx="12" fill="#345441" />
          <path d="M232 111h21M235 104v14M250 104v14" stroke="#E0F57A" strokeWidth="4" strokeLinecap="round" />

          <rect x="65" y="153" width="40" height="25" rx="8" fill="#41654F" />
          <path d="m76 165 5 5 12-12" stroke="#E0F57A" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          <rect x="215" y="151" width="47" height="28" rx="9" fill="#E0F57A" />
          <path d="m228 165 6 6 14-14" stroke="#202B23" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );

    case "warmup":
      return (
        <img className="warmup-illustration" src={welcomeIllustration} alt="" aria-hidden />
      );

    default:
      return null;
  }
}

function InjurySharingHint({ enabled }: { enabled: boolean }) {
  return (
    <p className="field-hint injury-sharing-hint">
      <span>Stored on this device. Shared with the AI coach only if you turn on injury sharing.</span>
      <strong>Sharing: {enabled ? "On" : "Off"}</strong>
    </p>
  );
}

function Onboarding({
  onComplete,
  startAt = "intro",
  shareInjuries,
  onShareInjuriesChange,
}: {
  onComplete: (profile: UserProfile) => void;
  startAt?: "intro" | "account";
  shareInjuries: boolean;
  onShareInjuriesChange: (enabled: boolean) => void;
}) {
  const [phase, setPhase] = useState<"intro" | "account" | "login" | "profile" | "finalizing">(startAt);
  const [slideIdx, setSlideIdx] = useState(0);
  const [animKey, setAnimKey] = useState(0);
  const [profileStep, setProfileStep] = useState(0);
  const [profileEntryPhase, setProfileEntryPhase] = useState<"account" | "login">("account");
  const [formError, setFormError] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [grade, setGrade] = useState("");
  const [climbingStyle, setClimbingStyle] = useState("");
  const [climbingLocation, setClimbingLocation] = useState("");
  const [experienceLevel, setExperienceLevel] = useState("");
  const [fingerTrainingExperience, setFingerTrainingExperience] = useState("");
  const [goals, setGoals] = useState<string[]>([]);
  const [customGoal, setCustomGoal] = useState("");
  const [gender, setGender] = useState("");
  const [height, setHeight] = useState("");
  const [weight, setWeight] = useState("");
  const [currentInjuries, setCurrentInjuries] = useState("");
  const [trainingDays, setTrainingDays] = useState<string[]>([]);
  const [sessionsPerWeek, setSessionsPerWeek] = useState("");
  const [sessionLength, setSessionLength] = useState("");
  const [equipment, setEquipment] = useState<string[]>([]);

  const slide = INTRO_SLIDES[slideIdx];
  const isLastIntro = slideIdx === INTRO_SLIDES.length - 1;
  const steps = ["Account", "Terms", "Background", "Goals", "Body", "Logistics"];

  function nextSlide() {
    if (!isLastIntro) {
      setAnimKey((key) => key + 1);
      setSlideIdx((index) => index + 1);
    } else {
      setPhase("account");
    }
  }

  function prevSlide() {
    if (slideIdx > 0) {
      setAnimKey((key) => key + 1);
      setSlideIdx((index) => index - 1);
    }
  }

  function toggleValue(value: string, values: string[], setter: React.Dispatch<React.SetStateAction<string[]>>) {
    setter(values.includes(value) ? values.filter((item) => item !== value) : [...values, value]);
  }

  function completeLogin(emailAddress: string) {
    const emailName = emailAddress.split("@")[0].replace(/[._-]+/g, " ").trim();
    const displayName = emailName.replace(/\b\w/g, (letter) => letter.toUpperCase()) || "Climber";
    onComplete({ name: displayName, email: emailAddress, grade: "", note: "", height: "", armSpan: "", goals: [] });
  }

  function handleEmailLogin(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoginError("");
    if (!loginEmail.includes("@") || !loginPassword) {
      setLoginError("Enter your email and password to continue.");
      return;
    }
    completeLogin(loginEmail.trim());
  }

  function nextProfileStep() {
    setFormError("");
    if (profileStep === 0) {
      if (!name.trim() || !email.trim() || !password) {
        setFormError("Please complete your name, email, and password.");
        return;
      }
      if (!email.includes("@")) {
        setFormError("Enter a valid email address.");
        return;
      }
      if (password.length < 8) {
        setFormError("Your password must be at least 8 characters.");
        return;
      }
    }
    if (profileStep === 1 && !acceptedTerms) {
      setFormError("You need to agree to the terms to continue.");
      return;
    }
    if (profileStep < steps.length - 1) {
      setProfileStep((step) => step + 1);
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }

    const allGoals = customGoal.trim() ? [...goals, customGoal.trim()] : goals;
    const completedProfile = {
      name: name.trim(), email: email.trim(), grade, note: "", height, armSpan: "", gender, weight,
      goals: allGoals, climbingStyle, climbingLocation, experienceLevel, fingerTrainingExperience,
      currentInjuries, sessionsPerWeek, trainingDays, sessionLength, equipment,
    };
    setPhase("finalizing");
    window.setTimeout(() => onComplete(completedProfile), 2400);
  }

  function PickGroup({ options, value, onChange }: { options: string[]; value: string; onChange: (value: string) => void }) {
    return (
      <div className="pick-group">
        {options.map((option) => (
          <Button key={option} type="button" variant="ghost" className={`pick-option${value === option ? " selected" : ""}`} onClick={() => onChange(value === option ? "" : option)} aria-pressed={value === option}>
            {value === option && <Icon name="check" size={13} />}{option}
          </Button>
        ))}
      </div>
    );
  }

  function MultiPick({ options, values, onToggle }: { options: string[]; values: string[]; onToggle: (value: string) => void }) {
    return (
      <div className="goal-chips">
        {options.map((option) => (
          <Button key={option} type="button" variant="ghost" className={`goal-chip${values.includes(option) ? " selected" : ""}`} onClick={() => onToggle(option)} aria-pressed={values.includes(option)}>
            {values.includes(option) && <Icon name="check" size={13} />}{option}
          </Button>
        ))}
      </div>
    );
  }

  if (phase === "finalizing") return (
    <div className="plan-loading-shell" aria-live="polite" aria-busy="true">
      <div className="plan-loading-visual">
        <div className="plan-loading-orb"><Icon name="spark" size={28} /></div>
        <div className="plan-loading-ring" />
      </div>
      <Heading level={1} className="plan-loading-title">AI Coach is finalizing your plan</Heading>
      <p>Personalizing your sessions, recovery, and goals.</p>
      <div className="plan-loading-dots" aria-hidden><span /><span /><span /></div>
    </div>
  );

  if (phase === "intro") return (
    <div className="intro-shell">
      {slideIdx > 0 && <Button variant="ghost" className="intro-top-back" onClick={prevSlide} aria-label="Previous slide"><Icon name="arrow" /></Button>}
      <Button variant="ghost" className="intro-skip" onClick={() => setPhase("account")}>Skip</Button>
      <div className="intro-visual"><SlideVisual key={animKey} id={slide.id} /></div>
      <div className="intro-body">
        <div key={animKey} className="slide-content-anim">
          <div className="eyebrow">{slide.eyebrow}</div>
          <Heading level={1} className="intro-title">{slide.title}</Heading>
          <p className="intro-desc">{slide.body}</p>
        </div>
        <div className="slide-dots intro-slide-dots">{INTRO_SLIDES.map((_, index) => <div key={index} className={`slide-dot${index === slideIdx ? " active" : ""}`} />)}</div>
        <div className="intro-footer">
          <Button className="intro-cta-btn" onClick={nextSlide}>{isLastIntro ? "Get started" : "Continue"} <Icon name="arrow" /></Button>
        </div>
      </div>
    </div>
  );

  if (phase === "account") return (
    <div className="account-shell">
      <div className="account-visual"><div className="brand brand-light"><span>Bouldy</span></div></div>
      <div className="account-card">
        <Heading level={1} className="account-title">How would you like to start?</Heading>
        <p className="account-desc">Create a profile so Bouldy can remember you and personalize your coaching, or explore as a guest.</p>
        <div className="account-choices">
          <Button className="account-cta wide-button" onClick={() => { setProfileEntryPhase("account"); setPhase("profile"); }}>Create my profile <Icon name="arrow" /></Button>
          <Button variant="secondary" className="wide-button" onClick={() => onComplete({ name: "", grade: "", note: "", height: "", armSpan: "", goals: [] })}>Continue as guest</Button>
        </div>
      </div>
    </div>
  );

  if (phase === "login") return (
    <div className="account-shell login-shell">
      <div className="account-visual login-visual">
        <div className="login-visual-content">
          <div className="brand brand-light"><span>Bouldy</span></div>
        </div>
      </div>
      <main className="account-card login-card">
        <Button variant="ghost" className="login-back" onClick={() => setPhase("account")}>
          <span className="back-arrow"><Icon name="arrow" size={18} /></span> Back
        </Button>
        <div className="login-form-wrap">
          <Heading level={1} className="account-title login-title">Log in to Bouldy</Heading>
          <p className="account-desc login-desc">Welcome back. Choose how you’d like to continue.</p>

          <Button variant="secondary" className="wide-button google-login-button" onClick={() => completeLogin("climber@gmail.com")}>
            <svg className="google-mark" viewBox="0 0 24 24" aria-hidden>
              <path fill="#4285F4" d="M21.6 12.2c0-.7-.1-1.5-.2-2.2H12v4.3h5.4a4.6 4.6 0 0 1-2 3v2.8h3.4c2-1.9 3.1-4.6 3.1-7.9Z" />
              <path fill="#34A853" d="M12 22c2.8 0 5.2-.9 6.9-2.5l-3.4-2.8c-.9.6-2.1 1-3.5 1-2.7 0-5.1-1.9-5.9-4.4H2.6v2.9A10.4 10.4 0 0 0 12 22Z" />
              <path fill="#FBBC05" d="M6.1 13.3a6.2 6.2 0 0 1 0-3.9v-3H2.6a10.5 10.5 0 0 0 0 9.8l3.5-2.9Z" />
              <path fill="#EA4335" d="M12 5.1c1.5 0 2.9.5 4 1.6l3-3A10 10 0 0 0 2.6 6.4l3.5 3C6.9 6.9 9.3 5.1 12 5.1Z" />
            </svg>
            Continue with Google
          </Button>

          <div className="login-divider"><span>or continue with email</span></div>

          <form className="login-form" onSubmit={handleEmailLogin}>
            <div className="field-group field-group-flat">
              <label className="field-label" htmlFor="login-email">Email</label>
              <input id="login-email" className="text-field" type="email" autoComplete="email" value={loginEmail} onChange={(event) => setLoginEmail(event.target.value)} placeholder="alex@example.com" />
            </div>
            <div className="field-group">
              <label className="field-label" htmlFor="login-password">Password</label>
              <input id="login-password" className="text-field" type="password" autoComplete="current-password" value={loginPassword} onChange={(event) => setLoginPassword(event.target.value)} placeholder="Enter your password" />
            </div>
            {loginError && <div className="profile-form-error" role="alert">{loginError}</div>}
            <Button type="submit" className="wide-button login-submit">Log in <Icon name="arrow" /></Button>
          </form>

          <p className="login-create-prompt">New to Bouldy? <Button variant="ghost" onClick={() => { setProfileEntryPhase("login"); setProfileStep(0); setPhase("profile"); }}>Create an account</Button></p>
        </div>
      </main>
    </div>
  );

  return (
    <div className="profile-slideshow-shell">
      <aside className="profile-step-rail">
        <div className="profile-brand">Bouldy</div>
        <div className="profile-rail-copy">
          <div className="eyebrow">Personal setup</div>
          <Heading level={1} className="profile-rail-title">Tell us about yourself.</Heading>
          <p>A few thoughtful answers help your coach shape every session around you.</p>
        </div>
        <div className="profile-step-list" aria-label="Profile setup progress">
          {steps.map((step, index) => (
            <div key={step} className={`profile-step-item${index === profileStep ? " active" : ""}${index < profileStep ? " complete" : ""}`}>
              <span className="profile-step-dot">{index < profileStep ? <Icon name="check" size={13} /> : index + 1}</span>
              <span>{step}</span>
            </div>
          ))}
        </div>
      </aside>

      <main className="profile-slide-main">
        <div className="profile-slide-card slide-content-anim" key={profileStep}>
          {profileStep === 0 && <>
            <div className="profile-slide-heading"><Heading level={2}>Create your account</Heading></div>
            <div className="field-group"><label className="field-label" htmlFor="ob-name">Name</label><input id="ob-name" className="text-field" autoComplete="name" value={name} onChange={(event) => setName(event.target.value)} placeholder="Alex Morgan" /></div>
            <div className="field-group"><label className="field-label" htmlFor="ob-email">Email</label><input id="ob-email" className="text-field" type="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="alex@example.com" /></div>
            <div className="field-group"><label className="field-label" htmlFor="ob-password">Password</label><input id="ob-password" className="text-field" type="password" autoComplete="new-password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="At least 8 characters" /><p className="field-hint">Use 8 or more characters.</p></div>
            <p className="account-login-prompt">Already have an account? <Button variant="ghost" onClick={() => setPhase("login")}>Log in</Button></p>
          </>}

          {profileStep === 1 && <>
            <div className="profile-slide-heading"><div className="eyebrow">Terms & conditions</div><Heading level={2}>Before you start</Heading><p>To receive Bouldy’s services, please review and agree to the following:</p></div>
            <div className="terms-card">
              <Heading level={3}>Bouldy training agreement</Heading>
              <ul className="terms-list">
                <li className="important"><strong>Your data is required</strong><span>Your profile may include health data, such as injuries or pain. Bouldy needs this information to personalize its services.</span></li>
                <li className="important"><strong>Training has risks</strong><span>Climbing and training can cause injury or death. You are responsible for your own actions.</span></li>
                <li><strong>Listen to your body</strong><span>Stop if you feel sharp or increasing pain. Speak to a healthcare professional if you have an injury or health concern.</span></li>
                <li><strong>AI coach data</strong><span>Your chat messages, the last few messages of the chat, and some profile answers (climbing grade, goals, experience, training schedule and equipment) are sent to Google's Gemini AI. Google's free tier may use this to improve its products, and Figma's hosting may log messages. Your name, email, weight, height and gender stay on your device. Your injuries are only shared if you choose to below.</span></li>
              </ul>
            </div>
            <label className={`terms-agree${acceptedTerms ? " selected" : ""}`} htmlFor="terms-check"><input id="terms-check" type="checkbox" checked={acceptedTerms} onChange={(event) => setAcceptedTerms(event.target.checked)} /><span className="terms-checkmark"><Icon name="check" size={16} /></span><span>I have read and agree to the Terms & Conditions.</span></label>
            <label className={`terms-agree${shareInjuries ? " selected" : ""}`} htmlFor="injury-sharing-terms"><input id="injury-sharing-terms" type="checkbox" checked={shareInjuries} onChange={(event) => onShareInjuriesChange(event.target.checked)} /><span className="terms-checkmark"><Icon name="check" size={16} /></span><span>Optional: Share my current injuries with the AI coach so it can adapt my advice and Today's session. You can turn this off at any time in Settings &gt; Privacy.</span></label>
          </>}

          {profileStep === 2 && <>
            <div className="profile-slide-heading"><Heading level={2}>Climbing background</Heading></div>
            <div className="field-group"><div className="field-label">Current Font grade <span>Hardest grade you send consistently</span></div><div className="grade-grid profile-grade-grid">{FONT_GRADES.map((item) => <Button key={item} type="button" variant="ghost" className={`grade-option${grade === item ? " selected" : ""}`} onClick={() => setGrade(grade === item ? "" : item)} aria-pressed={grade === item}>{item}</Button>)}</div></div>
            <div className="field-group"><div className="field-label">Preferred climbing style</div><PickGroup options={["Bouldering", "Sports climbing", "Trad climbing", "Multi-pitch climbing"]} value={climbingStyle} onChange={setClimbingStyle} /></div>
            <div className="field-group"><div className="field-label">Where do you usually climb?</div><PickGroup options={["Indoors", "Outdoors", "Both"]} value={climbingLocation} onChange={setClimbingLocation} /></div>
            <div className="field-group"><div className="field-label">Experience level</div><PickGroup options={["Beginner", "Intermediate", "Advanced"]} value={experienceLevel} onChange={setExperienceLevel} /></div>
            <div className="field-group"><div className="field-label">Finger training experience</div><PickGroup options={["Beginner", "Intermediate", "Advanced"]} value={fingerTrainingExperience} onChange={setFingerTrainingExperience} /></div>
          </>}

          {profileStep === 3 && <>
            <div className="profile-slide-heading"><Heading level={2}>Your goals</Heading><p>Choose as many as you like. Your goals can change over time.</p></div>
            <div className="field-group"><div className="field-label">Choose your goals <span>Select all that apply</span></div><MultiPick options={GOALS} values={goals} onToggle={(goal) => toggleValue(goal, goals, setGoals)} /></div>
            <div className="field-group"><label className="field-label" htmlFor="custom-goal">Add your own goal <span>Optional</span></label><input id="custom-goal" className="text-field" value={customGoal} onChange={(event) => setCustomGoal(event.target.value)} placeholder="My personal goal is..." /></div>
          </>}

          {profileStep === 4 && <>
            <div className="profile-slide-heading"><Heading level={2}>Body metrics</Heading></div>
            <div className="field-group"><div className="field-label">Gender <span>Optional</span></div><PickGroup options={["Woman", "Man", "Non-binary", "Prefer not to say"]} value={gender} onChange={setGender} /></div>
            <div className="two-fields"><div className="field-group field-group-flat"><label className="field-label" htmlFor="ob-height">Height <span>cm</span></label><input id="ob-height" className="text-field" type="number" min={100} max={250} value={height} onChange={(event) => setHeight(event.target.value)} placeholder="175" /></div><div className="field-group field-group-flat"><label className="field-label" htmlFor="ob-weight">Weight <span>kg</span></label><input id="ob-weight" className="text-field" type="number" min={25} max={250} value={weight} onChange={(event) => setWeight(event.target.value)} placeholder="70" /></div></div>
            <div className="field-group"><label className="field-label" htmlFor="ob-injuries">Any current injuries or pain? <span>Optional</span></label><textarea id="ob-injuries" className="text-field note-field" value={currentInjuries} onChange={(event) => setCurrentInjuries(event.target.value)} placeholder="Tell us where, what movements affect it, and how it feels..." /><InjurySharingHint enabled={shareInjuries} /></div>
          </>}

          {profileStep === 5 && <>
            <div className="profile-slide-heading"><Heading level={2}>Logistics</Heading></div>
            <div className="field-group"><div className="field-label">Which days would you like to train? <span>Select all that apply</span></div><MultiPick options={["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]} values={trainingDays} onToggle={(day) => toggleValue(day, trainingDays, setTrainingDays)} /></div>
            <div className="field-group"><div className="field-label">How many training days per week?</div><PickGroup options={["1 day", "2 days", "3 days", "4 days", "5+ days"]} value={sessionsPerWeek} onChange={setSessionsPerWeek} /></div>
            <div className="field-group"><div className="field-label">How long should a session be?</div><PickGroup options={["30–45 min", "45–60 min", "60–90 min", "90+ min"]} value={sessionLength} onChange={setSessionLength} /></div>
            <div className="field-group"><div className="field-label">Equipment access <span>Select all that apply</span></div><MultiPick options={["Climbing wall", "Hangboard", "Kilter board", "Spray wall", "Weights / gym", "Resistance bands", "No equipment"]} values={equipment} onToggle={(item) => toggleValue(item, equipment, setEquipment)} /></div>
          </>}

          {formError && <div className="profile-form-error" role="alert">{formError}</div>}
          <div className="profile-slide-actions">
            {profileStep > 0
              ? <Button variant="secondary" onClick={() => { setFormError(""); setProfileStep((step) => step - 1); }}><span className="back-arrow"><Icon name="arrow" /></span> Back</Button>
              : <Button variant="secondary" onClick={() => { setFormError(""); setPhase(profileEntryPhase); }}><span className="back-arrow"><Icon name="arrow" /></span> Back</Button>}
            <Button onClick={nextProfileStep} disabled={profileStep === 1 && !acceptedTerms}>{profileStep === steps.length - 1 ? "Build my plan" : "Continue"} <Icon name="arrow" /></Button>
          </div>
        </div>
        <div className="profile-mobile-progress">
          <span>Step {profileStep + 1} of {steps.length}</span>
          <div className="profile-mobile-dots">{steps.map((step, index) => <span key={step} className={`profile-mobile-dot${index <= profileStep ? " active" : ""}`} />)}</div>
        </div>
      </main>
    </div>
  );
}
function Nav({ view, onChange, name }: { view: AppView; onChange: (view: AppView) => void; name: string }) {
  const items: { key: AppView; label: string; icon: IconName }[] = [
    { key: "today", label: "Today", icon: "home" },
    { key: "coach", label: "AI Coach", icon: "message" },
    { key: "workout", label: "Workouts", icon: "workout" },
    { key: "warmup", label: "Warm up", icon: "warmup" },
    { key: "history", label: "History", icon: "history" },
  ];
  return (
    <>
      <aside className="sidebar">
        <div className="brand sidebar-brand"><span className="brand-stone">🪨</span><span>Bouldy</span></div>
        <nav className="nav-list" aria-label="Main navigation">
          {items.map((item) => (
            <Button key={item.key} variant="ghost" className={`nav-item ${view === item.key ? "active" : ""}`} onClick={() => onChange(item.key)} aria-label={item.label}>
              <Icon name={item.icon} /><span>{item.label}</span>
            </Button>
          ))}
        </nav>
        <div className="sidebar-coach">
          <div className="coach-orb small"><Icon name="spark" size={18} /></div>
          <div><strong>AI Coach</strong><span>Ready when you are</span></div>
        </div>
        <Button variant="ghost" className="profile-button" onClick={() => onChange("settings")} aria-label="Profile">
          <span className="avatar">{name.trim().charAt(0).toUpperCase() || "C"}</span>
          <span><strong>{name || "Climber"}</strong><small>Settings & privacy</small></span>
          <Icon name="chevron" size={16} />
        </Button>
      </aside>
      <nav className="mobile-nav" aria-label="Mobile navigation">
        {[
          { key: "today" as AppView, label: "Today", icon: "home" as IconName },
          { key: "coach" as AppView, label: "Coach", icon: "message" as IconName },
          { key: "analyze" as AppView, label: "Analyze", icon: "target" as IconName },
          { key: "workout" as AppView, label: "Train", icon: "workout" as IconName, also: "warmup" as AppView },
          { key: "history" as AppView, label: "History", icon: "history" as IconName },
        ].map((item) => {
          const isActive = view === item.key || ("also" in item && view === item.also);
          return (
            <Button key={item.key} variant="ghost" className={`mobile-nav-item ${isActive ? "active" : ""}`} onClick={() => onChange(item.key)} aria-label={item.label}>
              <Icon name={item.icon} size={19} /><span>{item.label}</span>
            </Button>
          );
        })}
      </nav>
    </>
  );
}

function PageHeader({ eyebrow, title, description }: { eyebrow: string; title: string; description?: string }) {
  return (
    <header className="page-header">
      <div><div className="eyebrow" style={{ fontSize: 14 }}>{eyebrow}</div><Heading level={1} className="page-title">{title}</Heading></div>
    </header>
  );
}

function Today({ profile, logs, onChange, onLogged }: { profile: UserProfile; logs: WorkoutLog[]; onChange: (view: AppView) => void; onLogged: (log: WorkoutLog) => void }) {
  const today = new Date();
  const [todaySession, setTodaySession] = useState<GeneratedTodaySession>(() => getTodaySession(profile, logs));
  const [activePlan, setActivePlan] = useState<WorkoutPlan | null>(null);
  const profileSignature = JSON.stringify(profile);
  const todayDate = today.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long" });
  const weekStart = new Date(today);
  weekStart.setHours(0, 0, 0, 0);
  weekStart.setDate(weekStart.getDate() - ((weekStart.getDay() + 6) % 7));
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekEnd.getDate() + 7);
  const thisWeekLogs = logs.filter((log) => {
    const completedAt = new Date(log.completedAt);
    return completedAt >= weekStart && completedAt < weekEnd;
  });
  const completedDays = new Set(
    thisWeekLogs.map((log) => (new Date(log.completedAt).getDay() + 6) % 7),
  );
  const weeklyTarget = Number.parseInt(profile.sessionsPerWeek || "", 10) || 0;
  const sessionsRemaining = Math.max(weeklyTarget - thisWeekLogs.length, 0);
  const isGuest = !profile.name.trim();
  let insightMessage: string;

  useEffect(() => {
    setTodaySession(getTodaySession(profile, logs));
  }, [profileSignature, logs]);

  function completePlan() {
    if (!activePlan) return;
    const completedAt = new Date();
    onLogged({
      id: completedAt.getTime(),
      completedAt: completedAt.toISOString(),
      title: activePlan.title,
      date: "Today",
      duration: activePlan.duration,
      grade: profile.grade,
      result: `${activePlan.steps.length} exercises complete`,
    });
    setActivePlan(null);
  }

  function restoreGeneratedPlan() {
    setTodaySession(resetTodaySession(profile, logs));
  }

  if (isGuest) {
    const guestMessages = [
      "Every send starts with showing up.",
      "Small sessions add up.",
      "Climb well, rest well.",
      "Good technique makes hard moves feel easier.",
      "Today's goal: enjoy the movement.",
    ];
    const dayOfYear = Math.floor(
      (Date.UTC(today.getFullYear(), today.getMonth(), today.getDate()) - Date.UTC(today.getFullYear(), 0, 0)) / 86_400_000,
    );
    insightMessage = guestMessages[(dayOfYear - 1) % guestMessages.length];
  } else if (logs.length === 0) {
    insightMessage = `Your first session is ready${profile.goals.length ? `, picked for your goal: ${profile.goals[0]}` : ""}`;
  } else if (thisWeekLogs.length === 0) {
    const lastSession = new Date(Math.max(...logs.map((log) => new Date(log.completedAt).getTime())));
    const todayDateValue = Date.UTC(today.getFullYear(), today.getMonth(), today.getDate());
    const lastSessionDateValue = Date.UTC(lastSession.getFullYear(), lastSession.getMonth(), lastSession.getDate());
    const daysAgo = Math.max(0, Math.round((todayDateValue - lastSessionDateValue) / 86_400_000));
    const lastSessionWhen = daysAgo === 0 ? "today" : daysAgo === 1 ? "yesterday" : `${daysAgo} days ago`;
    insightMessage = `No sessions logged this week yet. Your last session was ${lastSessionWhen}.`;
  } else if (weeklyTarget > 0 && thisWeekLogs.length >= weeklyTarget) {
    insightMessage = "Weekly target reached.";
  } else {
    insightMessage = weeklyTarget > 0
      ? `${thisWeekLogs.length} of ${weeklyTarget} sessions this week.`
      : `${thisWeekLogs.length} sessions this week.`;
  }

  if (activePlan) {
    return <GuidedWorkout plan={activePlan} onExit={() => setActivePlan(null)} onComplete={completePlan} />;
  }

  return (
    <>
      <PageHeader eyebrow={todayDate} title={`Good morning${profile.name ? `, ${profile.name}` : ""}.`} />
      <div className="today-insight">
        <p>{insightMessage}</p>
        {isGuest && <small>Create a profile to track your training.</small>}
      </div>

      <div className="section-heading"><div><span className="eyebrow">Up next</span><Heading>Today's session</Heading></div><span className="session-time"><Icon name="clock" size={17} /> {todaySession.plan.duration}</span></div>
      <section className="today-grid">
        <article className="plan-card">
          <div className="plan-card-top">
            <div className="plan-icon"><Icon name="footprints" /></div>
            <div className="today-plan-status">
              <span className="tag tag-ai">{todaySession.adjustedByCoach ? "Adjusted by your coach" : "Recommended"}</span>
              {todaySession.adjustedByCoach && <Button variant="ghost" className="reset-today-session" onClick={restoreGeneratedPlan}>Reset to my plan</Button>}
            </div>
          </div>
          <Heading level={3}>{todaySession.plan.title}</Heading>
          <p className="recommended-reason">Why: {todaySession.reason}</p>
          {isGuest && <small className="today-session-note">Create a profile to make this session personal.</small>}
          <ol className="workout-steps">
            {todaySession.plan.steps.map((step, index) => <li key={`${step.title}-${index}`}><span>{String(index + 1).padStart(2, "0")}</span><div><strong>{step.title}</strong><small>{step.workLabel}</small></div></li>)}
          </ol>
          <Button className="wide-button" onClick={() => setActivePlan(todaySession.plan)}><Icon name="play" size={18} /> Start workout</Button>
        </article>

        <div className="side-stack">
          <article className="progress-card">
            <div className="card-heading-row"><div><span className="eyebrow">This week</span><Heading level={3}>Climbing load</Heading></div><strong>{thisWeekLogs.length} / {weeklyTarget}</strong></div>
            <div className="week-bars">
              {["M", "T", "W", "T", "F", "S", "S"].map((day, index) => <div key={`${day}-${index}`}><span className={completedDays.has(index) ? "filled" : ""} /><small>{day}</small></div>)}
            </div>
            <p>{weeklyTarget === 0
              ? "Set a weekly target in your profile."
              : sessionsRemaining === 0
                ? "Weekly target reached."
                : `${sessionsRemaining} more ${sessionsRemaining === 1 ? "session" : "sessions"} to hit your weekly target.`}</p>
          </article>
          <Button variant="secondary" className="quick-card" onClick={() => onChange("warmup")}>
            <span className="quick-icon"><Icon name="warmup" /></span><span><strong>Need a quick warm-up?</strong><small>Guided routines from 5–15 min</small></span><Icon name="chevron" />
          </Button>
          <Button variant="secondary" className="quick-card" onClick={() => onChange("history")}>
            <span className="quick-icon amber"><Icon name="history" /></span><span><strong>Review your progress</strong><small>See sessions, sends, and notes</small></span><Icon name="chevron" />
          </Button>
        </div>
      </section>
    </>
  );
}

type CoachProfileContext = {
  grade?: string;
  goals?: string[];
  experienceLevel?: string;
  fingerTrainingExperience?: string;
  climbingStyle?: string;
  climbingLocation?: string;
  sessionsPerWeek?: string;
  trainingDays?: string[];
  sessionLength?: string;
  equipment?: string[];
  currentInjuries?: string;
};

function injuryMentionFromMessage(message: string) {
  return /\b(injur(?:y|ed|ies)|pain(?:ful)?|hurt(?:s|ing)?|sore|swoll(?:en|ing)|swelling|numb(?:ness)?|fracture|sprain|strain|tendinitis|tendonitis)\b/i.test(message)
    ? message.trim().slice(0, 300)
    : undefined;
}

function Coach({
  profileContext,
  currentSession,
  shareInjuries,
  consented,
  onConsent,
  onOpenDataPolicy,
  onAcceptSession,
  onSaveInjury,
}: {
  profileContext: CoachProfileContext;
  currentSession: GeneratedTodaySession;
  shareInjuries: boolean;
  consented: boolean;
  onConsent: () => void;
  onOpenDataPolicy: () => void;
  onAcceptSession: (update: SessionUpdate) => void;
  onSaveInjury: (injury: string) => void;
}) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: "coach", text: "I'm ready to help. We can work on technique, structure a training week, or review a route. What's on your mind?" },
  ]);
  const [input, setInput] = useState("");
  const [showSaved, setShowSaved] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [promptSetIndex, setPromptSetIndex] = useState(0);
  const [savedMessages, setSavedMessages] = useState<SavedChatMessage[]>([]);
  const [savedMessagesLoaded, setSavedMessagesLoaded] = useState(false);
  const [debugMode, setDebugMode] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const suggestionScrollRef = useRef<HTMLDivElement>(null);
  const starterPrompts = COACH_PROMPT_SETS[promptSetIndex];

  useEffect(() => {
    setDebugMode(window.location.search === "?debug=1");
  }, []);

  useEffect(() => {
    try {
      setSavedMessages(JSON.parse(localStorage.getItem("bouldy-saved-coach-messages") || "[]"));
    } catch {
      setSavedMessages([]);
    }
    setSavedMessagesLoaded(true);
  }, []);

  useEffect(() => {
    if (!savedMessagesLoaded) return;
    localStorage.setItem("bouldy-saved-coach-messages", JSON.stringify(savedMessages));
  }, [savedMessages, savedMessagesLoaded]);

  function isMessageSaved(message: ChatMessage) {
    return savedMessages.some((saved) => saved.role === message.role && saved.text === message.text && saved.attachment === message.attachment);
  }

  function toggleSavedMessage(message: ChatMessage) {
    setSavedMessages((current) => {
      const existing = current.some((saved) => saved.role === message.role && saved.text === message.text && saved.attachment === message.attachment);
      if (existing) return current.filter((saved) => !(saved.role === message.role && saved.text === message.text && saved.attachment === message.attachment));
      return [...current, { ...message, id: `${Date.now()}-${Math.random()}` }];
    });
  }

  async function submit(text = input) {
    if (!consented || !text.trim()) return;
    const message = text.trim();
    const fallback = "I couldn't answer right now. Try again in a moment, or use one of the suggested prompts.";
    setMessages((current) => [...current, { role: "user", text: message }]);
    setInput("");
    let reply = fallback;
    let debugError: string | undefined;
    let sessionUpdate: SessionUpdate | undefined;
    try {
      const populatedProfileContext = Object.fromEntries(
        Object.entries(profileContext).filter(([, value]) =>
          Array.isArray(value)
            ? value.some((item) => item.trim())
            : typeof value === "string" && Boolean(value.trim()),
        ),
      ) as CoachProfileContext;
      const conversation = messages
        .slice(-6)
        .map(({ role, text }) => ({ role, text }));
      const currentSessionContext = !shareInjuries && currentSession.adaptedForProfileInjury
        ? {
            title: "an adapted lighter session",
            duration: currentSession.plan.duration,
            stepTitles: [],
          }
        : {
            title: currentSession.plan.title,
            duration: currentSession.plan.duration,
            ...(shareInjuries ? { reason: currentSession.reason } : {}),
            stepTitles: currentSession.plan.steps.map((step) => step.title),
          };
      const result = await askBouldyCoach({
        message,
        conversation,
        currentSession: currentSessionContext,
        ...populatedProfileContext,
      });
      if (result.ok) {
        reply = result.reply;
        sessionUpdate = result.sessionUpdate;
        debugError = `Finish reason: ${result.finishReason || "not provided"}`;
      } else {
        const status = result.status === null ? "" : ` · Status ${result.status}`;
        debugError = `${result.stage}${status}: ${result.message}`;
      }
    } catch {
      reply = fallback;
      debugError = "request to Gemini failed: Server function request failed.";
    }
    setMessages((current) => [
      ...current,
      {
        role: "coach",
        text: reply,
        debugError,
        sessionUpdate,
        injuryToSave: injuryMentionFromMessage(message),
      },
    ]);
  }

  function chooseSessionUpdate(index: number, decision: "accepted" | "kept") {
    const message = messages[index];
    if (decision === "accepted" && message.sessionUpdate) onAcceptSession(message.sessionUpdate);
    setMessages((current) => current.map((item, itemIndex) => itemIndex === index
      ? { ...item, sessionDecision: decision }
      : item));
  }

  function saveInjuryToProfile(index: number, injury: string) {
    onSaveInjury(injury);
    setMessages((current) => current.map((item, itemIndex) => itemIndex === index
      ? { ...item, injurySaved: true }
      : item));
  }

  function attach(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (file) setMessages((current) => [...current, { role: "user", text: "Can you analyze this for me?", attachment: file.name }, { role: "coach", text: "Absolutely. I'll look at movement efficiency, body position, foot choices, and where you may be losing tension. Add a note about what felt hardest, too." }]);
  }

  function refreshSuggestions() {
    setPromptSetIndex((current) => (current + 1) % COACH_PROMPT_SETS.length);
    suggestionScrollRef.current?.scrollTo({ left: 0, behavior: "smooth" });
  }

  return (
    <div className="coach-page">
      <section className="chat-card flex min-h-[calc(100dvh-260px)] flex-col [&>.composer]:mt-auto [&>.messages]:max-h-none [&>.messages]:flex-1">
        <div className="chat-header">
          <div className="coach-identity"><div className="coach-mark"><Icon name="mountain" size={22} /></div><div><strong>Bouldy Coach</strong><span>Your AI climbing coach</span></div></div>
          <Button variant="secondary" className="saved-toggle" onClick={() => setShowSaved((current) => !current)} aria-expanded={showSaved}><Icon name="bookmark" size={16} />Saved <span>{savedMessages.length}</span></Button>
        </div>
        {consented && showSaved && (
          <div className="saved-messages">
            <div className="saved-messages-heading"><div><strong>Saved messages</strong><span>Advice you want to revisit</span></div><Button variant="ghost" onClick={() => setShowSaved(false)} aria-label="Close saved messages"><Icon name="close" size={17} /></Button></div>
            {savedMessages.length === 0
              ? <p className="saved-empty">Save a useful chat bubble and it will appear here.</p>
              : <div className="saved-message-list">{savedMessages.map((message) => <div className="saved-message" key={message.id}><div><span>{message.role === "coach" ? "Bouldy Coach" : "You"}</span><p>{message.text}</p></div><Button variant="ghost" onClick={() => toggleSavedMessage(message)} aria-label="Remove saved message"><Icon name="bookmark" size={15} /></Button></div>)}</div>}
          </div>
        )}
        {!consented ? (
          <div className="coach-consent">
            <div className="coach-consent-icon"><Icon name="spark" size={24} /></div>
            <Heading level={1}>Before you talk to your AI coach</Heading>
            <ul>
              <li><strong>Your messages go to Google's AI</strong><span>Your messages and some profile answers are sent to Google's Gemini AI to write answers.</span></li>
              <li><strong>What is sent</strong><span>Your chat messages, your climbing grade, goals, experience, training schedule and equipment, and your current injuries, only if you turned on injury sharing.</span></li>
              <li><strong>What is not sent</strong><span>Your name, email, weight, height and gender. Your injuries, unless you turned on injury sharing.</span></li>
              <li><strong>Free tier</strong><span>Google may use what you send to improve its products. Figma, which hosts this prototype, may log messages.</span></li>
              <li><strong>Please</strong><span>Don't type names or contact details. You can tell the coach about pain or injuries so it can adapt your training, but it's not a doctor.</span></li>
              <li><strong>Your control</strong><span>Your profile and saved messages stay on this device until you delete them in Settings &gt; Privacy.</span></li>
            </ul>
            <div className="coach-consent-actions">
              <Button onClick={onConsent}>I understand, continue</Button>
              <Button variant="secondary" onClick={onOpenDataPolicy}>Read the full details</Button>
            </div>
          </div>
        ) : (
          <>
            <div className="messages">
              {messages.map((message, index) => (
                <div key={index} className={`message ${message.role}`}>
                  {message.role === "coach" && <div className="message-avatar"><Icon name="mountain" size={17} /></div>}
                  <div className="message-bubble">
                    {message.attachment && <span className="attachment"><Icon name="image" size={17} />{message.attachment}</span>}
                    <p>{message.text}</p>
                    {message.sessionUpdate && !message.sessionDecision && (
                      <div className="coach-session-update">
                        <span>Your coach suggests a new session for today</span>
                        <strong>{message.sessionUpdate.title}</strong>
                        <p>{message.sessionUpdate.reason}</p>
                        <div>
                          <Button onClick={() => chooseSessionUpdate(index, "accepted")}>Update today's session</Button>
                          <Button variant="secondary" onClick={() => chooseSessionUpdate(index, "kept")}>Keep current</Button>
                        </div>
                      </div>
                    )}
                    {message.sessionDecision && <small className="coach-message-status">{message.sessionDecision === "accepted" ? "Today's session updated" : "Current session kept"}</small>}
                    {message.injuryToSave && (
                      <div className="coach-injury-save">
                        <Button variant="secondary" disabled={message.injurySaved} onClick={() => saveInjuryToProfile(index, message.injuryToSave!)}>{message.injurySaved ? "Saved to profile" : "Save to my profile"}</Button>
                        {!shareInjuries && <small>Saved on this device only. Turn on injury sharing in Settings &gt; Privacy if you want the coach to remember it.</small>}
                      </div>
                    )}
                    {debugMode && message.debugError && <small className="message-debug">{message.debugError}</small>}
                    <Button variant="ghost" className={`message-save${isMessageSaved(message) ? " saved" : ""}`} onClick={() => toggleSavedMessage(message)} aria-pressed={isMessageSaved(message)}><Icon name="bookmark" size={16} />{isMessageSaved(message) ? "Saved" : "Save"}</Button>
                  </div>
                </div>
              ))}
              {messages.length === 1 && (
                <div className="suggestions" aria-label="Suggested prompts">
                  <div className="suggestion-scroll" ref={suggestionScrollRef}>
                    {starterPrompts.map((prompt) => <Button key={prompt} variant="secondary" onClick={() => submit(prompt)}>{prompt}</Button>)}
                    <Button variant="secondary" className="suggestion-refresh" onClick={refreshSuggestions} aria-label="Refresh suggested prompts"><Icon name="refresh" size={15} />Refresh</Button>
                  </div>
                </div>
              )}
            </div>
            <div className="composer">
              <div className="composer-input">
                <Button variant="icon" onClick={() => fileRef.current?.click()} aria-label="Add attachment"><Icon name="plus" /></Button>
                <p className="coach-disclaimer" style={{ margin: 0, textAlign: "left" }}><strong>Bouldy can make mistakes.</strong> Check important training, injury, and health advice before acting on it.</p>
                <input ref={fileRef} type="file" accept="image/*,video/*" hidden onChange={attach} />
                <textarea value={input} onChange={(event) => setInput(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); submit(); } }} placeholder="Ask about training, technique or a route" />
                <Button variant="icon" className={`voice-button${isListening ? " active" : ""}`} onClick={() => setIsListening((current) => !current)} aria-label={isListening ? "Stop voice input" : "Start voice input"} aria-pressed={isListening}><Icon name="microphone" size={18} /></Button>
                <Button variant="icon" className="send-button" onClick={() => submit()} aria-label="Send message"><Icon name="send" size={18} /></Button>
              </div>
            </div>
          </>
        )}
      </section>
    </div>
  );
}

function formatTimer(seconds: number) {
  const minutes = Math.floor(seconds / 60);
  return `${String(minutes).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
}

function getMovementType(title: string) {
  const name = title.toLowerCase();
  if (/push|press|dip/.test(name)) return "push";
  if (/squat|deadlift|step-up|lunge|hip|ankle|calf/.test(name)) return "legs";
  if (/pull|row|hang|lever|plank/.test(name)) return "pull";
  if (/stretch|circle|chin tuck|glide|flick|pulse|switch|tilt|rotation|mobility/.test(name)) return "mobility";
  return "climb";
}

function getMovementCues(title: string) {
  const type = getMovementType(title);
  if (type === "pull") return ["Start with long arms and engaged shoulders.", "Drive your elbows down or back without swinging."];
  if (type === "push") return ["Brace your core and keep a strong line through your body.", "Lower under control, then press smoothly without shrugging."];
  if (type === "legs") return ["Keep your whole foot planted and your knee tracking over your toes.", "Move from your hips and finish tall without rushing."];
  if (type === "mobility") return ["Move slowly through a comfortable, pain-free range.", "Keep the rest of your body relaxed and avoid forcing the end position."];
  return ["Look at the next hold before you move and place your feet quietly.", "Keep your hips close to the wall and breathe through each move."];
}

function MovementVisual({ title }: { title: string }) {
  const type = getMovementType(title);
  return (
    <svg className="movement-visual" viewBox="0 0 280 150" fill="none" aria-label={`Movement illustration for ${title}`} role="img">
      <path className="movement-ground" d="M28 128h224" />
      {type === "pull" && (
        <>
          <path className="movement-equipment" d="M72 26h136M86 26v18M194 26v18" />
          <circle className="movement-body" cx="140" cy="52" r="10" />
          <path className="movement-body" d="M140 62v35m0-27-27-24m27 24 27-24m-27 51-20 29m20-29 20 29" />
          <path className="movement-accent" d="M109 72 99 61m72 11 10-11" />
        </>
      )}
      {type === "push" && (
        <>
          <circle className="movement-body" cx="190" cy="74" r="10" />
          <path className="movement-body" d="m180 79-61 22-45 2m52-5-18 27m18-27 31 23m19-36-38 3-22 18" />
          <path className="movement-accent" d="m71 92-9 11 10 10m62-19 14 6-8 12" />
        </>
      )}
      {type === "legs" && (
        <>
          <circle className="movement-body" cx="140" cy="48" r="10" />
          <path className="movement-body" d="M140 58v38m0-24-24 19m24-19 24 19m-24 5-30 28m30-28 34 27" />
          <path className="movement-equipment" d="M89 125h42m19 0h45" />
          <path className="movement-accent" d="m101 104 9-10 11 7m38 0 11-7 9 10" />
        </>
      )}
      {type === "mobility" && (
        <>
          <circle className="movement-body" cx="140" cy="45" r="10" />
          <path className="movement-body" d="M140 55v45m0-27-31 13m31-13 31 13m-31 14-23 27m23-27 23 27" />
          <path className="movement-accent" d="M101 65c-12 4-18 14-17 25m95-25c12 4 18 14 17 25M89 82l-5 8-7-7m114-1 5 8 7-7" />
        </>
      )}
      {type === "climb" && (
        <>
          <path className="movement-equipment" d="M64 128 91 22h126l-22 106" />
          <path className="movement-hold" d="m112 42 13-4 5 8-16 5Zm51 15 15-3 3 10-16 3Zm-65 31 14-3 4 9-16 4Zm61 18 14-4 5 9-17 5Z" />
          <circle className="movement-body" cx="142" cy="65" r="9" />
          <path className="movement-body" d="m138 74-9 28m4-15-23-13m22 11 30-20m-33 37-22 17m22-17 29 15" />
          <path className="movement-accent" d="m105 70 6 4-3 8m52-21 4 5-8 5" />
        </>
      )}
    </svg>
  );
}

function GuidedWorkout({
  plan,
  onExit,
  onComplete,
}: {
  plan: WorkoutPlan;
  onExit: () => void;
  onComplete: () => void;
}) {
  const [stepIndex, setStepIndex] = useState(0);
  const [phase, setPhase] = useState<"exercise" | "rest" | "restComplete" | "complete">("exercise");
  const [remaining, setRemaining] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [paused, setPaused] = useState(false);
  const [showGuide, setShowGuide] = useState(false);
  const step = plan.steps[stepIndex];
  const movementCues = getMovementCues(step.title);
  const isLast = stepIndex === plan.steps.length - 1;
  const timerRunning = phase === "rest" && !paused;

  useEffect(() => {
    if (phase === "complete") return;
    const timer = window.setInterval(() => setElapsed((value) => value + 1), 1000);
    return () => window.clearInterval(timer);
  }, [phase]);

  useEffect(() => {
    if (!timerRunning) return;
    const timer = window.setInterval(() => {
      setRemaining((value) => {
        if (value > 1) return value - 1;
        setPaused(false);
        setPhase("restComplete");
        return 0;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [timerRunning]);

  function startRest() {
    setRemaining(step.restSeconds);
    setPaused(false);
    setPhase("rest");
  }

  function nextStep() {
    const next = stepIndex + 1;
    setStepIndex(next);
    setRemaining(0);
    setPaused(false);
    setShowGuide(false);
    setPhase("exercise");
  }

  const phaseLabel = phase === "rest"
    ? "Rest"
    : phase === "restComplete"
      ? "Rest complete"
      : "Self-paced exercise";

  if (phase === "complete") {
    return (
      <section className="active-workout">
        <article className="workout-complete">
          <span className="completion-mark"><Icon name="check" size={34} /></span>
          <span className="eyebrow">Workout complete</span>
          <Heading level={1}>Strong work.</Heading>
          <p>You completed all {plan.steps.length} exercises in {plan.title}.</p>
          <div><Icon name="clock" size={17} /> Total session time {formatTimer(elapsed)}</div>
          <Button onClick={onComplete}>Save and finish</Button>
        </article>
      </section>
    );
  }

  return (
    <section className="active-workout">
      <Button variant="ghost" className="back-button" onClick={onExit}>
        <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="m15 18-6-6 6-6"/></svg>
        Exit workout
      </Button>
      <div className="workout-progress">
        <span>Exercise {stepIndex + 1} of {plan.steps.length}</span>
        <strong>{plan.title}</strong>
        <div><i style={{ width: `${((stepIndex + (phase === "rest" || phase === "restComplete" ? 1 : 0)) / plan.steps.length) * 100}%` }} /></div>
      </div>
      <article className={`exercise-player ${phase === "rest" ? "is-resting" : ""}`}>
        <span className="eyebrow">{phaseLabel}</span>
        <Heading level={2}>{phase === "rest" ? "Recover and reset" : step.title}</Heading>
        <p>{phase === "rest" ? "Breathe slowly, shake out, and prepare for the next exercise." : step.instructions}</p>
        {phase === "exercise" && (
          <div className="movement-guide">
            <Button variant="secondary" onClick={() => setShowGuide((value) => !value)} aria-expanded={showGuide}>
              {showGuide ? "Hide demonstration" : "How to do it"}
            </Button>
            {showGuide && (
              <div className="movement-guide-panel">
                <MovementVisual title={step.title} />
                <div>
                  <strong>Move with control</strong>
                  <span>{movementCues[0]}</span>
                  <span>{movementCues[1]}</span>
                  <span>Stop if you feel sharp pain or lose your form.</span>
                </div>
              </div>
            )}
          </div>
        )}
        <div className="player-meta">
          <span><Icon name="check" size={16} /> Recommended: {step.workLabel}</span>
          <span><Icon name="stopwatch" size={16} /> Rest: {step.restSeconds ? step.restSeconds < 60 ? `${step.restSeconds} sec` : `${Math.round(step.restSeconds / 60)} min` : "None"}</span>
        </div>
        {phase === "exercise" ? (
          <div className="self-paced-status">
            <Icon name="check" size={24} />
            <div><strong>Take the time you need</strong><span>Complete the recommended work with good form, then continue when you feel ready.</span></div>
          </div>
        ) : (
          <div className="countdown" aria-live="polite">
            <small>{phaseLabel}</small>
            <strong>{formatTimer(remaining)}</strong>
          </div>
        )}
        <div className="player-actions">
          {phase === "exercise" && (
            isLast
              ? <Button onClick={() => setPhase("complete")}><Icon name="check" size={17} /> Complete workout</Button>
              : step.restSeconds > 0
                ? <Button onClick={startRest}><Icon name="stopwatch" size={17} /> Start rest</Button>
                : <Button onClick={nextStep}>Next exercise <Icon name="arrow" size={17} /></Button>
          )}
          {phase === "rest" && (
            <>
              <Button onClick={() => setPaused((value) => !value)}>{paused ? "Resume" : "Pause"}</Button>
              <Button variant="secondary" onClick={() => { setRemaining(0); setPhase("restComplete"); }}>Skip rest</Button>
            </>
          )}
          {phase === "restComplete" && <Button onClick={nextStep}>Next exercise <Icon name="arrow" size={17} /></Button>}
        </div>
      </article>
      <div className="session-elapsed"><Icon name="clock" size={16} /> Session time {formatTimer(elapsed)}</div>
      <div className="up-next">
        <span className="eyebrow">{isLast ? "Final exercise" : "Up next"}</span>
        <strong>{isLast ? "Complete and save your session" : plan.steps[stepIndex + 1].title}</strong>
      </div>
    </section>
  );
}

function StrengthView({ onBack, onStart }: { onBack: () => void; onStart: (plan: WorkoutPlan) => void }) {
  const sections = [
    {
      title: "Pulls",
      icon: "workout" as IconName,
      desc: "Target the upper back and lats — the engine behind every big move.",
      exercises: [
        { name: "Weighted pull-ups", sets: "3 × 5–6", note: "Add weight via belt or vest. Full hang to chin-over-bar." },
        { name: "Horizontal rows", sets: "3 × 8–10", note: "Rings or barbell. Keep your body rigid and squeeze the shoulder blades." },
        { name: "Bent-over rows", sets: "3 × 8", note: "Hip-hinge position, barbell or dumbbell. Elbows drive back, not out." },
      ],
    },
    {
      title: "Pushes",
      icon: "target" as IconName,
      desc: "Shoulder stability and mantle strength — essential for topping out.",
      exercises: [
        { name: "Push-ups", sets: "3 × 10–15", note: "Add a pause at the bottom for extra shoulder recruitment." },
        { name: "Overhead press", sets: "3 × 6–8", note: "Barbell or dumbbells. Brace your core hard to protect the lower back." },
        { name: "Ring dips", sets: "3 × 6–8", note: "Control the descent — rings challenge shoulder stability throughout." },
      ],
    },
    {
      title: "Hinges and Squats",
      icon: "arrow" as IconName,
      desc: "Lower-body drive for high-stepping, rocking over, and generating momentum.",
      exercises: [
        { name: "Deadlifts", sets: "3 × 5", note: "Focus on hip hinge mechanics. Conventional or Romanian both work well." },
        { name: "Goblet squats", sets: "3 × 10", note: "Hold a kettlebell at chest height. Drive knees out over the toes." },
        { name: "Step-ups", sets: "3 × 8 each leg", note: "Use a box at knee height. Drive through the heel, not the toes." },
      ],
    },
    {
      title: "Core",
      icon: "spark" as IconName,
      desc: "Body tension on overhangs — without it, your feet pop and your hips sag.",
      exercises: [
        { name: "Hanging knee tucks", sets: "3 × 10–12", note: "Dead hang from a bar. Compress knees to chest and lower with control." },
        { name: "Front lever holds", sets: "3 × 5–10 sec", note: "Scale with tucked or single-leg variations. Quality over duration." },
        { name: "Plank variations", sets: "3 × 30–45 sec", note: "Side planks and hollow-body holds are the most climbing-specific." },
      ],
    },
  ];

  const guidelines = [
    { label: "Frequency", text: "Train strength 2 days per week to avoid overloading your forearms." },
    { label: "Volume", text: "Keep it minimalist — 2 to 3 sets per exercise, 5 to 10 reps per set." },
    { label: "Recovery", text: "Rest 3 to 4 minutes between heavy sets, or separate lifting from climbing by at least 4–6 hours." },
    { label: "Fingers", text: "Supplement this with hangboard or wall climbing. Connective tissue adapts slower than muscle — be patient." },
  ];

  return (
    <>
      <PageHeader eyebrow="Supplemental training" title="Strength exercises" description="Climber-focused strength work to support your time on the wall." />
      <Button variant="ghost" style={{ marginBottom: 24, color: "var(--muted)", gap: 6 }} onClick={onBack}>
        <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="m15 18-6-6 6-6"/></svg>
        Back to overview
      </Button>
      <div style={{ display: "grid", gap: 20, marginBottom: 28 }}>
        {sections.map((sec) => {
          const plan: WorkoutPlan = {
            title: `${sec.title} strength session`,
            duration: "30–40 min",
            steps: sec.exercises.map((exercise, index) => ({
              title: exercise.name,
              instructions: exercise.note,
              workLabel: exercise.sets,
              workSeconds: 180,
              restSeconds: index === sec.exercises.length - 1 ? 0 : 180,
            })),
          };
          return (
          <article key={sec.title} className="plan-card">
            <div className="plan-card-top"><div className="plan-icon"><Icon name={sec.icon} /></div><span className="tag">{sec.title}</span></div>
            <div role="heading" aria-level={3} className="heading" style={{ marginTop: 14, fontSize: 20 }}>{sec.title}</div>
            <p style={{ margin: "6px 0 18px", color: "var(--muted)", fontSize: 14 }}>{sec.desc}</p>
            <ol className="workout-steps">
              {sec.exercises.map((ex, i) => (
                <li key={ex.name}>
                  <span>0{i + 1}</span>
                  <div><strong>{ex.name}</strong><small>{ex.note}</small><small>{ex.sets} · Rest 3 min</small></div>
                </li>
              ))}
            </ol>
            <Button className="wide-button" onClick={() => onStart(plan)}><Icon name="play" size={16} /> Start workout</Button>
          </article>
          );
        })}
      </div>
      <article className="plan-card">
        <div className="plan-card-top"><div className="plan-icon"><Icon name="calendar" /></div><span className="tag">Programming</span></div>
        <div role="heading" aria-level={3} className="heading" style={{ marginTop: 14, fontSize: 20 }}>Programming guidelines</div>
        <div style={{ display: "grid", gap: 12, marginTop: 18 }}>
          {guidelines.map((g) => (
            <div key={g.label} style={{ display: "grid", gridTemplateColumns: "120px 1fr", gap: 12, paddingTop: 12, borderTop: "1px solid var(--border)" }}>
              <strong style={{ fontSize: 13, color: "var(--primary-dark)" }}>{g.label}</strong>
              <p style={{ margin: 0, fontSize: 13, color: "var(--muted)", lineHeight: 1.55 }}>{g.text}</p>
            </div>
          ))}
        </div>
      </article>
    </>
  );
}

function EnduranceView({ onBack, onStart }: { onBack: () => void; onStart: (plan: WorkoutPlan) => void }) {
  const types = [
    { name: "Aerobic Capacity (ARC)", desc: "Low-intensity, continuous climbing for 20–45 minutes where you barely feel a pump. Builds aerobic base and capillary density in the forearms." },
    { name: "Power Endurance", desc: "High-intensity climbing under a deep pump, relying on combined aerobic and anaerobic systems. The feeling of fighting through a forearm scream." },
  ];

  const workouts = [
    {
      name: "Continuous ARCing",
      type: "Aerobic base",
      duration: "20–45 min",
      steps: [
        "Choose a traversing wall or auto-belay at 3–4 grades below your limit.",
        "Climb continuously without touching the floor for the full duration.",
        "Focus on smooth footwork, breathing, and never gripping harder than needed.",
        "The goal is to stay below the pump threshold — you should be able to hold a conversation.",
      ],
    },
    {
      name: "4×4s",
      type: "Power endurance",
      duration: "~45 min",
      steps: [
        "Choose four boulder problems two grades below your maximum.",
        "Climb all four back-to-back with zero rest between problems.",
        "Rest exactly 5 minutes, then repeat for 4 total sets.",
        "The pump in set 3 and 4 is the point — stay in control and keep moving.",
      ],
    },
    {
      name: "Double Laps",
      type: "Power endurance",
      duration: "~40 min",
      steps: [
        "Choose a moderate lead route or long boulder problem.",
        "Climb it once, lower or step off immediately, then climb the exact same line again.",
        "Rest 10 minutes, then repeat for 3–4 total pairs.",
        "Resist the urge to shake out on the route — maintain movement throughout.",
      ],
    },
    {
      name: "Aerobic Intervals",
      type: "Aerobic base",
      duration: "20 min",
      steps: [
        "Choose a moderate grade — something you can climb comfortably but that produces a light pump.",
        "Climb for 1 minute on, then rest for 1 minute off. Repeat for 10 rounds.",
        "Track your pump level each round — the goal is to build and then fully recover.",
        "Increase rounds or density as fitness improves over weeks.",
      ],
    },
  ];

  return (
    <>
      <PageHeader eyebrow="Supplemental training" title="Endurance training" description="Manage forearm fatigue and train the right energy systems — not just get tired." />
      <Button variant="ghost" style={{ marginBottom: 24, color: "var(--muted)", gap: 6 }} onClick={onBack}>
        <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="m15 18-6-6 6-6"/></svg>
        Back to overview
      </Button>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 16, marginBottom: 28 }}>
        {types.map((t) => (
          <div key={t.name} style={{ padding: 22, background: "var(--forest)", borderRadius: "var(--radius-md)", color: "white" }}>
            <span className="eyebrow" style={{ color: "var(--moss-light)" }}>Type</span>
            <div className="heading" style={{ marginTop: 10, marginBottom: 8, fontSize: 18, color: "white" }}>{t.name}</div>
            <p style={{ margin: 0, fontSize: 13, lineHeight: 1.6, color: "#aeb8ae" }}>{t.desc}</p>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gap: 20 }}>
        {workouts.map((w) => {
          const rounds = w.name === "4×4s" ? 4 : w.name === "Double Laps" ? 3 : w.name === "Aerobic Intervals" ? 10 : 1;
          const workSeconds = w.name === "Continuous ARCing" ? 1200 : w.name === "Aerobic Intervals" ? 60 : w.name === "4×4s" ? 240 : 360;
          const restSeconds = w.name === "4×4s" ? 300 : w.name === "Double Laps" ? 600 : w.name === "Aerobic Intervals" ? 60 : 0;
          const plan: WorkoutPlan = {
            title: w.name,
            duration: w.duration,
            steps: Array.from({ length: rounds }, (_, index) => ({
              title: rounds > 1 ? `${w.name} · Round ${index + 1}` : w.name,
              instructions: w.steps.join(" "),
              workLabel: w.name === "Aerobic Intervals" ? "1 min on" : rounds > 1 ? `Round ${index + 1} of ${rounds}` : w.duration,
              workSeconds,
              restSeconds,
            })),
          };
          return (
          <article key={w.name} className="plan-card">
            <div className="plan-card-top">
              <div className="plan-icon"><Icon name="stopwatch" /></div>
              <span className="tag">{w.type}</span>
            </div>
            <div role="heading" aria-level={3} className="heading" style={{ marginTop: 14, fontSize: 20 }}>{w.name}</div>
            <span style={{ display: "flex", alignItems: "center", gap: 6, color: "var(--muted)", fontSize: 12, margin: "6px 0 18px" }}><Icon name="clock" size={14} />{w.duration}</span>
            <span className="rest-label"><Icon name="stopwatch" size={14} /> Rest: {restSeconds ? `${Math.round(restSeconds / 60)} min between rounds` : "As needed after completion"}</span>
            <ol className="workout-steps">
              {w.steps.map((step, i) => (
                <li key={i}><span>0{i + 1}</span><div><p style={{ margin: 0, fontSize: 13, lineHeight: 1.5 }}>{step}</p></div></li>
              ))}
            </ol>
            <Button className="start-plan-button" onClick={() => onStart(plan)}><Icon name="play" size={16} /> Start workout</Button>
          </article>
          );
        })}
      </div>
    </>
  );
}

function Workouts({ grade, onLogged, onWarmup }: { grade: string; onLogged: (log: WorkoutLog) => void; onWarmup: () => void }) {
  const [subView, setSubView] = useState<"strength" | "endurance" | null>(null);
  const [activePlan, setActivePlan] = useState<WorkoutPlan | null>(null);
  const precisionPlan: WorkoutPlan = {
    title: "Precision & movement",
    duration: "55 min",
    steps: [
      { title: "Progressive warm-up", instructions: "Raise your pulse, mobilize shoulders and hips, then climb three easy problems.", workLabel: "10 min", workSeconds: 600, restSeconds: 30 },
      { title: "Silent feet", instructions: "Climb four easy problems without foot noise. Watch each foothold until your toe lands.", workLabel: "4 problems · 15 min", workSeconds: 900, restSeconds: 180 },
      { title: "Limit bouldering", instructions: `Choose three hard problems around ${grade} and above. Make high-quality attempts with full recovery.`, workLabel: "3 projects · 25 min", workSeconds: 1500, restSeconds: 240 },
      { title: "Cool down", instructions: "Finish with easy traversing, relaxed breathing, and gentle forearm mobility.", workLabel: "5 min", workSeconds: 300, restSeconds: 0 },
    ],
  };
  const projectPlan: WorkoutPlan = {
    title: "Project session",
    duration: "70 min",
    steps: [
      { title: "Movement rehearsal", instructions: "Warm up on similar angles, then rehearse the project's key positions at low intensity.", workLabel: "15 min", workSeconds: 900, restSeconds: 180 },
      { title: "Quality attempts", instructions: "Make five focused attempts. Refine one decision after each attempt instead of changing everything.", workLabel: "5 attempts · 35 min", workSeconds: 2100, restSeconds: 300 },
      { title: "Links and finish", instructions: "Practice the hardest link, then finish with two easier confidence-building climbs.", workLabel: "20 min", workSeconds: 1200, restSeconds: 0 },
    ],
  };

  function completePlan() {
    if (!activePlan) return;
    const completedAt = new Date();
    onLogged({ id: completedAt.getTime(), completedAt: completedAt.toISOString(), title: activePlan.title, date: "Today", duration: activePlan.duration, grade, result: `${activePlan.steps.length} exercises complete` });
    setActivePlan(null);
  }

  if (activePlan) return <GuidedWorkout plan={activePlan} onExit={() => setActivePlan(null)} onComplete={completePlan} />;
  if (subView === "strength") return <StrengthView onBack={() => setSubView(null)} onStart={setActivePlan} />;
  if (subView === "endurance") return <EnduranceView onBack={() => setSubView(null)} onStart={setActivePlan} />;

  return (
    <>
      <PageHeader eyebrow="Train with intent" title="Sessions" description="Coach-built sessions that adapt to your current grade and goals." />
      <details className="programming-guide">
        <summary><span><Icon name="calendar" size={18} /> Plan your week</span><span className="programming-guide-meta"><small>Build a balanced, sustainable week</small><Icon name="chevron" size={17} /></span></summary>
        <div>
          <p><strong>Balance:</strong> Pair 2–3 climbing sessions with no more than 2 strength sessions each week.</p>
          <p><strong>Recover:</strong> Keep at least one full rest day and avoid hard finger training on consecutive days.</p>
          <p><strong>Progress:</strong> Increase either volume or intensity gradually, never both in the same week.</p>
          <p><strong>Adjust:</strong> Stop if pain is sharp or changes your movement. Fatigue is feedback, not a target.</p>
        </div>
      </details>
      <section className="workout-library">
        <article className="featured-workout">
          <div><span className="tag tag-ai">Recommended</span><Heading>Precision & movement</Heading><p>Build better feet, body awareness, and efficient movement before high-quality attempts.</p><div className="metadata"><span><Icon name="clock" size={17} />55 min</span><span><Icon name="footprints" size={17} />Technique</span><span><Icon name="mountain" size={17} />Font grades · {grade || "Not set"}</span></div></div>
          <Button onClick={() => setActivePlan(precisionPlan)}><Icon name="play" size={17} /> Start session</Button>
        </article>
        <div className="workout-options">
          <article className="option-card"><div className="plan-icon"><Icon name="workout" /></div><Heading level={3}>Strength exercises</Heading><p>Climber-focused pulls, pushes, hinges, and core work to build transferable strength.</p><span><Icon name="clock" size={16} />45–60 min</span><Button variant="secondary" onClick={() => setSubView("strength")}>View exercises <Icon name="arrow" size={17} /></Button></article>
          <article className="option-card"><div className="plan-icon"><Icon name="stopwatch" /></div><Heading level={3}>Endurance training</Heading><p>ARC, 4×4s, and interval sessions to manage pump and build climbing-specific fitness.</p><span><Icon name="clock" size={16} />20–45 min</span><Button variant="secondary" onClick={() => setSubView("endurance")}>View workouts <Icon name="arrow" size={17} /></Button></article>
          <article className="option-card"><div className="plan-icon"><Icon name="workout" /></div><Heading level={3}>Project session</Heading><p>A structured approach to your project with full recovery between quality attempts.</p><span><Icon name="clock" size={16} />70 min · 3–5 min rest</span><Button variant="secondary" onClick={() => setActivePlan(projectPlan)}><Icon name="play" size={16} /> Start workout</Button></article>
          <article className="option-card option-card-warmup">
            <div className="plan-icon"><Icon name="warmup" /></div>
            <Heading level={3}>Warm-ups</Heading>
            <p>Targeted routines for every body area — fingers, wrists, shoulders, hips, and more.</p>
            <span><Icon name="clock" size={16} />5 – 10 min</span>
            <Button variant="secondary" onClick={onWarmup}>View warm-ups <Icon name="arrow" size={17} /></Button>
          </article>
        </div>
      </section>
    </>
  );
}

function Warmup({ onBack }: { onBack: () => void }) {
  const [area, setArea] = useState<WarmupArea>("Full body");
  const [activePlan, setActivePlan] = useState<WorkoutPlan | null>(null);
  const total = useMemo(() => WARMUPS[area].length * 3, [area]);
  const warmupSteps = WARMUPS[area].map((exercise, index) => {
    const amount = Number(exercise.time.match(/\d+/)?.[0] || 60);
    const workSeconds = exercise.time.includes("min")
      ? amount * 60
      : exercise.time.includes("sec")
        ? amount * (exercise.time.includes("each") ? 2 : 1)
        : 60;
    return {
      title: exercise.title,
      instructions: exercise.note,
      workLabel: exercise.time,
      workSeconds,
      restSeconds: index === WARMUPS[area].length - 1 ? 0 : 30,
    };
  });
  const warmupPlan: WorkoutPlan = { title: `${area} warm-up`, duration: `${total} min`, steps: warmupSteps };

  if (activePlan) return <GuidedWorkout plan={activePlan} onExit={() => setActivePlan(null)} onComplete={() => setActivePlan(null)} />;

  return (
    <>
      <PageHeader eyebrow="Prepare to move" title="Warm-up guide" description="Choose a focus and follow a short, climbing-specific routine." />
      <Button variant="ghost" style={{ marginBottom: 20, color: "var(--muted)", gap: 6 }} onClick={onBack}>
        <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="m15 18-6-6 6-6"/></svg>
        Back to overview
      </Button>
      <div className="warmup-layout">
        <aside className="warmup-categories">
          <span className="eyebrow">Choose an area</span>
          {Object.keys(WARMUPS).map((item) => <Button key={item} variant="ghost" className={area === item ? "active" : ""} onClick={() => setArea(item as WarmupArea)}><span>{item}</span><Icon name="chevron" size={17} /></Button>)}
        </aside>
        <section className="warmup-routine">
          <div className="routine-header"><div><span className="eyebrow">{total} minute routine</span><Heading>{area}</Heading><p>Move within a pain-free range. This should leave you warm, never tired.</p></div><div className="routine-number">0{WARMUPS[area].length}</div></div>
          <div className="exercise-list">
            {WARMUPS[area].map((exercise, index) => (
              <article key={exercise.title} className="exercise-card">
                <span className="exercise-index">0{index + 1}</span>
                <div><Heading level={3}>{exercise.title}</Heading><p>{exercise.note}</p>{index < WARMUPS[area].length - 1 && <small>Rest 30 sec before the next exercise</small>}</div>
                <strong><Icon name="clock" size={16} />{exercise.time}</strong>
              </article>
            ))}
          </div>
          <Button className="wide-button" onClick={() => setActivePlan(warmupPlan)}><Icon name="play" size={17} /> Start guided warm-up</Button>
        </section>
      </div>
    </>
  );
}

function ProfilePickGroup({ options, value, onChange }: { options: string[]; value: string; onChange: (value: string) => void }) {
  return (
    <div className="pick-group">
      {options.map((option) => (
        <Button key={option} type="button" variant="ghost" className={`pick-option${value === option ? " selected" : ""}`} onClick={() => onChange(value === option ? "" : option)} aria-pressed={value === option}>
          {value === option && <Icon name="check" size={13} />}{option}
        </Button>
      ))}
    </div>
  );
}

function ProfileMultiPick({ options, values, onToggle }: { options: string[]; values: string[]; onToggle: (value: string) => void }) {
  return (
    <div className="goal-chips">
      {options.map((option) => (
        <Button key={option} type="button" variant="ghost" className={`goal-chip${values.includes(option) ? " selected" : ""}`} onClick={() => onToggle(option)} aria-pressed={values.includes(option)}>
          {values.includes(option) && <Icon name="check" size={13} />}{option}
        </Button>
      ))}
    </div>
  );
}

function ProfileEditor({ profile, shareInjuries, onSave, onCancel }: { profile: UserProfile; shareInjuries: boolean; onSave: (profile: UserProfile) => void; onCancel: () => void }) {
  const [name, setName] = useState(profile.name);
  const [email, setEmail] = useState(profile.email || "");
  const [grade, setGrade] = useState(profile.grade);
  const [climbingStyle, setClimbingStyle] = useState(profile.climbingStyle || "");
  const [climbingLocation, setClimbingLocation] = useState(profile.climbingLocation || "");
  const [experienceLevel, setExperienceLevel] = useState(profile.experienceLevel || "");
  const [fingerTrainingExperience, setFingerTrainingExperience] = useState(profile.fingerTrainingExperience || "");
  const [goals, setGoals] = useState(profile.goals.filter((goal) => GOALS.includes(goal)));
  const [customGoal, setCustomGoal] = useState(profile.goals.find((goal) => !GOALS.includes(goal)) || "");
  const [gender, setGender] = useState(profile.gender || "");
  const [height, setHeight] = useState(profile.height);
  const [weight, setWeight] = useState(profile.weight || "");
  const [currentInjuries, setCurrentInjuries] = useState(profile.currentInjuries || "");
  const [trainingDays, setTrainingDays] = useState(profile.trainingDays || []);
  const [sessionsPerWeek, setSessionsPerWeek] = useState(profile.sessionsPerWeek || "");
  const [sessionLength, setSessionLength] = useState(profile.sessionLength || "");
  const [equipment, setEquipment] = useState(profile.equipment || []);
  const [formError, setFormError] = useState("");

  function toggleValue(value: string, setter: React.Dispatch<React.SetStateAction<string[]>>) {
    setter((current) => current.includes(value) ? current.filter((item) => item !== value) : [...current, value]);
  }

  function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setFormError("");
    const cleanName = name.trim();
    const cleanEmail = email.trim();
    const heightValue = Number(height);
    const weightValue = Number(weight);

    if (!cleanName) {
      setFormError("Enter your name.");
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      setFormError("Enter a valid email address.");
      return;
    }
    if (height && (!Number.isFinite(heightValue) || heightValue < 100 || heightValue > 250)) {
      setFormError("Height must be between 100 and 250 cm.");
      return;
    }
    if (weight && (!Number.isFinite(weightValue) || weightValue < 25 || weightValue > 250)) {
      setFormError("Weight must be between 25 and 250 kg.");
      return;
    }

    onSave({
      ...profile,
      name: cleanName,
      email: cleanEmail,
      grade,
      climbingStyle,
      climbingLocation,
      experienceLevel,
      fingerTrainingExperience,
      goals: customGoal.trim() ? [...goals, customGoal.trim()] : goals,
      gender,
      height,
      weight,
      currentInjuries,
      trainingDays,
      sessionsPerWeek,
      sessionLength,
      equipment,
    });
  }

  return (
    <form className="history-profile-form profile-slide-card" onSubmit={submit} noValidate>
      <section className="history-profile-form-section">
        <Heading level={3}>Background</Heading>
        <div className="two-fields">
          <div className="field-group field-group-flat"><label className="field-label" htmlFor="profile-name">Name</label><input id="profile-name" className="text-field" autoComplete="name" value={name} onChange={(event) => setName(event.target.value)} /></div>
          <div className="field-group field-group-flat"><label className="field-label" htmlFor="profile-email">Email</label><input id="profile-email" className="text-field" type="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} /></div>
        </div>
        <div className="field-group"><div className="field-label">Current Font grade</div><div className="grade-grid profile-grade-grid">{FONT_GRADES.map((item) => <Button key={item} type="button" variant="ghost" className={`grade-option${grade === item ? " selected" : ""}`} onClick={() => setGrade(grade === item ? "" : item)} aria-pressed={grade === item}>{item}</Button>)}</div></div>
        <div className="field-group"><div className="field-label">Preferred climbing style</div><ProfilePickGroup options={["Bouldering", "Sports climbing", "Trad climbing", "Multi-pitch climbing"]} value={climbingStyle} onChange={setClimbingStyle} /></div>
        <div className="field-group"><div className="field-label">Where do you usually climb?</div><ProfilePickGroup options={["Indoors", "Outdoors", "Both"]} value={climbingLocation} onChange={setClimbingLocation} /></div>
        <div className="field-group"><div className="field-label">Experience level</div><ProfilePickGroup options={["Beginner", "Intermediate", "Advanced"]} value={experienceLevel} onChange={setExperienceLevel} /></div>
        <div className="field-group"><div className="field-label">Finger training experience</div><ProfilePickGroup options={["Beginner", "Intermediate", "Advanced"]} value={fingerTrainingExperience} onChange={setFingerTrainingExperience} /></div>
      </section>

      <section className="history-profile-form-section">
        <Heading level={3}>Goals</Heading>
        <div className="field-group"><div className="field-label">Choose your goals <span>Select all that apply</span></div><ProfileMultiPick options={GOALS} values={goals} onToggle={(goal) => toggleValue(goal, setGoals)} /></div>
        <div className="field-group"><label className="field-label" htmlFor="profile-custom-goal">Add your own goal <span>Optional</span></label><input id="profile-custom-goal" className="text-field" value={customGoal} onChange={(event) => setCustomGoal(event.target.value)} /></div>
      </section>

      <section className="history-profile-form-section">
        <Heading level={3}>Body</Heading>
        <div className="field-group"><div className="field-label">Gender <span>Optional</span></div><ProfilePickGroup options={["Woman", "Man", "Non-binary", "Prefer not to say"]} value={gender} onChange={setGender} /></div>
        <div className="two-fields">
          <div className="field-group field-group-flat"><label className="field-label" htmlFor="profile-height">Height <span>cm, 100–250</span></label><input id="profile-height" className="text-field" type="number" min={100} max={250} value={height} onChange={(event) => setHeight(event.target.value)} /></div>
          <div className="field-group field-group-flat"><label className="field-label" htmlFor="profile-weight">Weight <span>kg, 25–250</span></label><input id="profile-weight" className="text-field" type="number" min={25} max={250} value={weight} onChange={(event) => setWeight(event.target.value)} /></div>
        </div>
        <div className="field-group"><label className="field-label" htmlFor="profile-injuries">Current injuries or pain <span>Optional</span></label><textarea id="profile-injuries" className="text-field note-field" value={currentInjuries} onChange={(event) => setCurrentInjuries(event.target.value)} /><InjurySharingHint enabled={shareInjuries} /></div>
      </section>

      <section className="history-profile-form-section">
        <Heading level={3}>Logistics</Heading>
        <div className="field-group"><div className="field-label">Training days <span>Select all that apply</span></div><ProfileMultiPick options={["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]} values={trainingDays} onToggle={(day) => toggleValue(day, setTrainingDays)} /></div>
        <div className="field-group"><div className="field-label">How many training days per week?</div><ProfilePickGroup options={["1 day", "2 days", "3 days", "4 days", "5+ days"]} value={sessionsPerWeek} onChange={setSessionsPerWeek} /></div>
        <div className="field-group"><div className="field-label">Session length</div><ProfilePickGroup options={["30–45 min", "45–60 min", "60–90 min", "90+ min"]} value={sessionLength} onChange={setSessionLength} /></div>
        <div className="field-group"><div className="field-label">Equipment <span>Select all that apply</span></div><ProfileMultiPick options={["Climbing wall", "Hangboard", "Kilter board", "Spray wall", "Weights / gym", "Resistance bands", "No equipment"]} values={equipment} onToggle={(item) => toggleValue(item, setEquipment)} /></div>
      </section>

      {formError && <div className="profile-form-error" role="alert">{formError}</div>}
      <div className="history-profile-form-actions">
        <Button type="submit">Save changes</Button>
        <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>
      </div>
    </form>
  );
}

function History({ logs, profile, shareInjuries, onStart, onUpdateProfile, onCreateProfile }: { logs: WorkoutLog[]; profile: UserProfile; shareInjuries: boolean; onStart: () => void; onUpdateProfile: (profile: UserProfile) => void; onCreateProfile: () => void }) {
  const hasHistory = logs.length > 0;
  const chartValues = [2, 3, 2, 4, 3, 4, Math.min(5, Math.max(1, logs.length))];
  const [editingProfile, setEditingProfile] = useState(false);
  const [profileUpdated, setProfileUpdated] = useState(false);

  function saveProfile(updatedProfile: UserProfile) {
    onUpdateProfile(updatedProfile);
    setEditingProfile(false);
    setProfileUpdated(true);
  }

  return (
    <>
      <PageHeader eyebrow="Your progress" title="Workout history" description="Every focused session adds up. Review the work you've done." />
      <section className="history-profile-section">
        <div className="section-heading"><Heading level={2}>Your profile</Heading></div>
        {!profile.name.trim() ? (
          <div className="history-profile-guest">
            <p>Create a profile to save your goals and information.</p>
            <Button onClick={onCreateProfile}>Create my profile</Button>
          </div>
        ) : editingProfile ? (
          <ProfileEditor profile={profile} shareInjuries={shareInjuries} onSave={saveProfile} onCancel={() => setEditingProfile(false)} />
        ) : (
          <>
            {profileUpdated && <p className="history-profile-updated" role="status">Profile updated</p>}
            <div className="history-profile-card">
              <div className="history-profile-card-heading"><div><span>Your profile</span><strong>{profile.name}</strong></div><Button variant="secondary" onClick={() => { setProfileUpdated(false); setEditingProfile(true); }}>Edit profile</Button></div>
              <dl>
                <div><dt>Current Font grade</dt><dd>{profile.grade || "Not added"}</dd></div>
                <div><dt>Goals</dt><dd>{profile.goals.length ? profile.goals.join(", ") : "Not added"}</dd></div>
                <div><dt>Weekly training days</dt><dd>{profile.trainingDays?.length ? profile.trainingDays.join(", ") : "Not added"}</dd></div>
              </dl>
            </div>
          </>
        )}
      </section>
      <section className="history-summary">
        <div><span>Training frequency</span><strong>{hasHistory ? profile.sessionsPerWeek || `${logs.length} / week` : "–"}</strong><small>{hasHistory ? "recent weekly average" : "Complete a session to see this"}</small></div>
        <div><span>Session length</span><strong>{hasHistory ? profile.sessionLength || logs[0].duration : "–"}</strong><small>{hasHistory ? "average duration" : "Complete a session to see this"}</small></div>
        <div><span>Current grade</span><strong>{hasHistory ? profile.grade || logs[0].grade : "–"}</strong><small>{hasHistory ? "Font scale" : "Complete a session to see this"}</small></div>
      </section>

      {!hasHistory ? (
        <section className="history-empty">
          <div className="history-empty-illustration" role="img" aria-label="Illustration placeholder">Illustration</div>
          <Heading level={2}>Your progress starts here</Heading>
          <p>Finish your first session to see your training frequency, session length and grade progress.</p>
          <Button onClick={onStart}><Icon name="play" size={17} /> Start today’s session</Button>
        </section>
      ) : (
        <section className="history-progress-grid">
          <article className="streak-card">
            <span className="eyebrow">Current streak</span>
            <strong>{Math.min(12, logs.length + 2)} weeks</strong>
            <p>Keep one quality session in each week to continue your streak.</p>
          </article>
          <article className="frequency-card">
            <div><span className="eyebrow">Sessions per week</span><strong>Last 7 weeks</strong></div>
            <div className="frequency-chart" aria-label="Sessions per week bar chart">
              {chartValues.map((value, index) => <div key={index}><span style={{ height: `${value * 18}%` }} /><small>W{index + 1}</small></div>)}
            </div>
          </article>
        </section>
      )}

      <section className="history-list">
        <div className="section-heading"><Heading level={2}>Recent sessions</Heading></div>
        {!hasHistory && <p className="history-list-empty">No sessions yet.</p>}
        {logs.map((log) => <article className="history-row" key={log.id}><div className="history-date"><span>{log.date === "Today" ? "24" : log.date.match(/\d+/)?.[0]}</span><small>{log.date === "Today" ? "JUN" : "JUN"}</small></div><div className="history-main"><Heading level={3}>{log.title}</Heading><p>{log.date}</p></div><div className="history-stat"><span>Duration</span><strong>{log.duration}</strong></div><div className="history-stat"><span>Top grade</span><strong>{log.grade}</strong></div><div className="history-stat"><span>Result</span><strong>{log.result}</strong></div><Icon name="chevron" /></article>)}
      </section>
    </>
  );
}

function PrivacySettings({
  aiSharing,
  shareInjuries,
  onToggleSharing,
  onToggleInjurySharing,
  onBack,
  onOpenDataPolicy,
}: {
  aiSharing: boolean;
  shareInjuries: boolean;
  onToggleSharing: (enabled: boolean) => void;
  onToggleInjurySharing: (enabled: boolean) => void;
  onBack: () => void;
  onOpenDataPolicy: () => void;
}) {
  const [confirmDelete, setConfirmDelete] = useState(false);

  function downloadData() {
    const payload = JSON.stringify({
      profile: JSON.parse(localStorage.getItem("bouldy-profile") || "null"),
      sessions: JSON.parse(localStorage.getItem("bouldy-workout-logs") || "[]"),
      savedCoachMessages: JSON.parse(localStorage.getItem("bouldy-saved-coach-messages") || "[]"),
      shareInjuries: localStorage.getItem("bouldy-share-injuries") === "true",
      todaySession: JSON.parse(localStorage.getItem("bouldy-today-session") || "null"),
    }, null, 2);
    const url = URL.createObjectURL(new Blob([payload], { type: "application/json" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = "bouldy-data.json";
    link.click();
    URL.revokeObjectURL(url);
  }

  function deleteAllData() {
    localStorage.removeItem("bouldy-profile");
    localStorage.removeItem("bouldy-workout-logs");
    localStorage.removeItem("bouldy-saved-coach-messages");
    localStorage.removeItem("bouldy-ai-consent");
    localStorage.removeItem("bouldy-share-injuries");
    localStorage.removeItem("bouldy-today-session");
    window.location.reload();
  }

  return (
    <div className="privacy-page">
      <Button variant="ghost" className="back-button" onClick={onBack}><span className="back-arrow"><Icon name="arrow" size={18} /></span> Back</Button>
      <PageHeader eyebrow="Settings" title="Privacy" description="Manage how Bouldy uses your information." />
      <section className="privacy-card">
        <div className="privacy-setting-row">
          <div><Heading level={2}>AI coach data sharing</Heading><p>Allow your profile and messages to be processed to generate personalized coaching.</p></div>
          <label className="privacy-toggle">
            <input type="checkbox" checked={aiSharing} onChange={(event) => onToggleSharing(event.target.checked)} />
            <span aria-hidden />
            <span className="sr-only">AI coach data sharing</span>
          </label>
        </div>
        <div className={`privacy-setting-row${!aiSharing ? " disabled" : ""}`}>
          <div><Heading level={2}>Share injuries with the AI coach</Heading><p>Lets the coach adapt advice and Today's session to your injuries. Your injuries are sent to Google's Gemini AI.</p></div>
          <label className="privacy-toggle">
            <input type="checkbox" checked={shareInjuries} disabled={!aiSharing} onChange={(event) => onToggleInjurySharing(event.target.checked)} />
            <span aria-hidden />
            <span className="sr-only">Share injuries with the AI coach</span>
          </label>
        </div>
        <div className="privacy-actions">
          <Button variant="secondary" onClick={onOpenDataPolicy}>Read the full data policy <Icon name="arrow" size={17} /></Button>
          <Button variant="secondary" onClick={downloadData}>Download my data <Icon name="arrow" size={17} /></Button>
          <Button variant="secondary" className="delete-data-button" onClick={() => setConfirmDelete(true)}>Delete all my data on this device</Button>
          <small className="privacy-delete-note">Messages already sent to Google's Gemini AI cannot be deleted from here.</small>
          {confirmDelete && (
            <div className="privacy-delete-confirmation" role="alertdialog" aria-labelledby="delete-data-question">
              <p id="delete-data-question">This will delete your profile, workout history, saved coach messages and AI sharing choice from this device. This cannot be undone. Continue?</p>
              <div className="privacy-delete-confirmation-actions">
                <Button className="confirm-delete-button" onClick={deleteAllData} autoFocus>Delete</Button>
                <Button variant="secondary" onClick={() => setConfirmDelete(false)}>Cancel</Button>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

function DataPolicy({ onBack }: { onBack: () => void }) {
  return (
    <div className="privacy-page">
      <Button variant="ghost" className="back-button" onClick={onBack}><span className="back-arrow"><Icon name="arrow" size={18} /></span> Back</Button>
      <PageHeader eyebrow="Privacy" title="How Bouldy uses your data" description="A short guide to what is shared and what stays on your device." />
      <div className="privacy-card data-policy-card">
        <section className="data-policy-section">
          <Heading level={2}>What is sent to Google</Heading>
          <ul>
            <li>Your chat message and the last few messages of the chat</li>
            <li>Your climbing grade, goals, experience, training schedule and equipment</li>
            <li>Your current injuries, only if you turned on injury sharing</li>
          </ul>
          <p>These are sent to Google's Gemini AI to write an answer.</p>
        </section>
        <section className="data-policy-section">
          <Heading level={2}>What is not sent</Heading>
          <ul>
            <li>Your name, email, weight, height and gender</li>
            <li>Your injuries, unless you turned on injury sharing</li>
            <li>Photos or videos</li>
          </ul>
        </section>
        <section className="data-policy-section">
          <Heading level={2}>Health information</Heading>
          <p>Injuries and pain are health information. They're only sent to Google if you turn on injury sharing. You can turn it off at any time in Settings &gt; Privacy. Information already sent can't be deleted from here.</p>
        </section>
        <section className="data-policy-section">
          <Heading level={2}>Free tier</Heading>
          <ul>
            <li>This prototype uses Google's free tier. Google may use what you send to improve its products.</li>
          </ul>
        </section>
        <section className="data-policy-section">
          <Heading level={2}>Hosting</Heading>
          <ul>
            <li>The prototype is hosted by Figma. Figma's systems may log the messages you send.</li>
          </ul>
        </section>
        <section className="data-policy-section">
          <Heading level={2}>What stays on this device</Heading>
          <ul>
            <li>Your profile, workout history and saved messages are stored in this browser on this device. They stay until you delete them.</li>
          </ul>
        </section>
        <section className="data-policy-section">
          <Heading level={2}>Deleting your data</Heading>
          <ul>
            <li>You can delete everything stored on this device in Settings &gt; Privacy.</li>
            <li>Messages already sent to Google cannot be deleted from here.</li>
          </ul>
        </section>
        <section className="data-policy-section">
          <Heading level={2}>Please</Heading>
          <ul>
            <li>Don't type names or contact details. You can tell the coach about pain or injuries so it can adapt your training, but it's not a doctor.</li>
            <li>This is a prototype. Check important training, injury and health advice before acting on it.</li>
          </ul>
        </section>
      </div>
    </div>
  );
}

export default function App() {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [view, setView] = useState<AppView>("today");
  const [logs, setLogs] = useState<WorkoutLog[]>([]);
  const [aiSharing, setAiSharing] = useState(false);
  const [shareInjuries, setShareInjuries] = useState(false);
  const [todaySessionRevision, setTodaySessionRevision] = useState(0);
  const [onboardingStartAt, setOnboardingStartAt] = useState<"intro" | "account" | null>(null);
  const [settingsReturnView, setSettingsReturnView] = useState<AppView>("today");
  const [policyReturnView, setPolicyReturnView] = useState<AppView>("today");
  const [storageLoaded, setStorageLoaded] = useState(false);

  useEffect(() => {
    try {
      setProfile(JSON.parse(localStorage.getItem("bouldy-profile") || "null"));
      const storedLogs = JSON.parse(localStorage.getItem("bouldy-workout-logs") || "[]") as StoredWorkoutLog[];
      setLogs(storedLogs.map(normalizeWorkoutLog));
    } catch {
      setProfile(null);
      setLogs([]);
    }
    setAiSharing(localStorage.getItem("bouldy-ai-consent") === "true");
    setShareInjuries(localStorage.getItem("bouldy-share-injuries") === "true");
    setStorageLoaded(true);
  }, []);

  useEffect(() => {
    if (!storageLoaded) return;
    localStorage.setItem("bouldy-workout-logs", JSON.stringify(logs));
  }, [logs, storageLoaded]);

  function updateAiSharing(enabled: boolean) {
    setAiSharing(enabled);
    if (enabled) localStorage.setItem("bouldy-ai-consent", "true");
    else {
      localStorage.removeItem("bouldy-ai-consent");
      updateInjurySharing(false);
    }
  }

  function updateInjurySharing(enabled: boolean) {
    setShareInjuries(enabled);
    if (enabled) localStorage.setItem("bouldy-share-injuries", "true");
    else localStorage.removeItem("bouldy-share-injuries");
  }

  function changeView(nextView: AppView) {
    if (nextView === "settings") setSettingsReturnView(view);
    setView(nextView);
  }

  function openDataPolicy(returnView: AppView) {
    setPolicyReturnView(returnView);
    setView("data-policy");
  }

  function complete(p: UserProfile) {
    localStorage.setItem("bouldy-profile", JSON.stringify(p));
    setProfile(p);
  }

  function completeReplayedOnboarding(p: UserProfile) {
    if (p.name.trim()) complete(p);
    setOnboardingStartAt(null);
  }

  function acceptCoachSession(update: SessionUpdate) {
    if (!profile) return;
    saveTodaySession(profile, {
      plan: {
        title: update.title,
        duration: update.duration,
        steps: update.steps,
      },
      reason: update.reason,
      adjustedByCoach: true,
      adaptedForProfileInjury: Boolean(shareInjuries && profile.currentInjuries?.trim()),
    });
    setTodaySessionRevision((revision) => revision + 1);
  }

  function saveChatInjury(injury: string) {
    if (!profile) return;
    const existing = profile.currentInjuries?.trim() || "";
    const currentInjuries = existing && !existing.toLowerCase().includes(injury.toLowerCase())
      ? `${existing}\n${injury}`
      : existing || injury;
    complete({ ...profile, currentInjuries });
  }

  if (!storageLoaded) return null;
  if (!profile) return <Onboarding onComplete={complete} shareInjuries={shareInjuries} onShareInjuriesChange={updateInjurySharing} />;
  if (onboardingStartAt) return <Onboarding startAt={onboardingStartAt} onComplete={completeReplayedOnboarding} shareInjuries={shareInjuries} onShareInjuriesChange={updateInjurySharing} />;
  const currentTodaySession = getTodaySession(profile, logs);
  void todaySessionRevision;

  return (
    <div className="app-shell">
      <Nav view={view} onChange={changeView} name={profile.name} />
      <main className="main-content">
        {view === "today" && <Today profile={profile} logs={logs} onChange={setView} onLogged={(log) => { setLogs((current) => [log, ...current]); setView("history"); }} />}
        {view === "coach" && <Coach profileContext={{ grade: profile.grade, goals: profile.goals, experienceLevel: profile.experienceLevel, fingerTrainingExperience: profile.fingerTrainingExperience, climbingStyle: profile.climbingStyle, climbingLocation: profile.climbingLocation, sessionsPerWeek: profile.sessionsPerWeek, trainingDays: profile.trainingDays, sessionLength: profile.sessionLength, equipment: profile.equipment, currentInjuries: aiSharing && shareInjuries ? profile.currentInjuries : undefined }} currentSession={currentTodaySession} shareInjuries={shareInjuries} consented={aiSharing} onConsent={() => updateAiSharing(true)} onOpenDataPolicy={() => openDataPolicy("coach")} onAcceptSession={acceptCoachSession} onSaveInjury={saveChatInjury} />}
        {view === "workout" && <Workouts grade={profile.grade} onLogged={(log) => { setLogs((current) => [log, ...current]); setView("history"); }} onWarmup={() => setView("warmup")} />}
        {view === "warmup" && <Warmup onBack={() => setView("workout")} />}
        {view === "analyze" && null}
        {view === "history" && <History logs={logs} profile={profile} shareInjuries={shareInjuries} onStart={() => setView("workout")} onUpdateProfile={complete} onCreateProfile={() => setOnboardingStartAt("account")} />}
        {view === "settings" && <PrivacySettings aiSharing={aiSharing} shareInjuries={shareInjuries} onToggleSharing={updateAiSharing} onToggleInjurySharing={updateInjurySharing} onBack={() => setView(settingsReturnView)} onOpenDataPolicy={() => openDataPolicy("settings")} />}
        {view === "data-policy" && <DataPolicy onBack={() => setView(policyReturnView)} />}
        {view === "coach" && <div className="privacy-shortcut"><Button onClick={() => changeView("settings")}>Privacy</Button></div>}
      </main>
    </div>
  );
}
